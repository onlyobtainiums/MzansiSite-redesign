# MzansiSite Studio — Barber Template Pack (v1)

Six genuinely different, working barber-business website designs for South African barbershops,
wrapped in a template **selector with auto-rotation** and a **live personalisation preview**.

This is deliverable 1 of a repeatable system: Barber only. The same architecture (registry +
shared content context + per-industry sample data) is intended to scale to 52+ industries.

---

## 1. The six template families

| Family   | Strategy        | Composition highlights                                                                 |
|----------|-----------------|----------------------------------------------------------------------------------------|
| Velvet   | Hero-first      | Full-bleed editorial hero, oversized serif wordmark, meta strip, numbered menu, frames, visit block |
| Forge    | Services-first  | Price list IS the hero: category filter tabs, dotted leaders, mono prices, enquiry band, shop cards |
| Savanna  | Trust-first     | Identity card first, hours/location/contact grids, service standards, **honest credentials module** |
| Praxis   | Gallery-first   | Featured frame, masonry portfolio, caption-labelled services, **real empty states** for no photos |
| Market   | About-first     | Chaptered story with drop-cap, dashed kraft cards, illustrated map card, story fallbacks |
| Vital    | Enquiry-first   | Contact panel + working WhatsApp enquiry form; **never claims a booking is confirmed** |

Templates are pure renderers (`src/templates/<family>/<Family>Template.tsx`) driven by
`TemplateProps`. They respond to **container width** (Tailwind CSS container queries), so the
same component renders its mobile layout in a 390px frame and desktop layout at full width.

## 2. Features

- **Design selector** — 6.5s auto-rotation with progress bar, prev/next, six named direct-select
  pills, pause/play. Pauses on hover, focus or touch, and stays paused after any manual choice
  until you press play. Auto-rotation is completely off under `prefers-reduced-motion`.
- **Working preview personalisation** — name, tagline, story, WhatsApp, phone, email, address,
  area, **structured opening hours (day / open / close / closed)**, services + prices +
  categories, credentials, 1 logo, up to 6 photos with **add / replace / remove / reorder**.
- **Live, lossless switching** — all content lives in `StudioContext`; switching designs or a
  subscription-status change never resets content.
- **Mobile / desktop device frames** — real responsive behaviour via container queries.
- **Tab-local draft** — text details auto-save to sessionStorage (clearly labelled as this-tab
  only). Photos/logo are never persisted by the static prototype (see §5).
- **One entitlement gate** — `deriveEntitlement()` in `src/config/entitlements.ts` decides photo
  capacity. The context enforces it (not just the UI), and the same pure function is provided for
  the platform API to enforce server-side.

## 3. Setup

```bash
npm install
npm run dev      # local dev
npm run build    # production build (single-file dist/index.html, assets inlined)
```

Requires Node 18+. No environment variables, APIs or services are needed for the prototype.

## 4. Structure & file map

```
src/
  App.tsx                      View shell: chooser ⇄ studio
  types.ts                     Shared contracts (HourRow is structured: label/open/close/closed)
  config/
    entitlements.ts            deriveEntitlement() + assertPhotoCapacity() — THE capacity gate
    limits.ts                  Upload validation; resolvePaidPhotoLimit()→null (platform-injected)
  data/barberPack.ts           Labelled SAMPLE content (services, prices, hours, photos)
  state/StudioContext.tsx      Content, entitlement, reorder, tab-local text draft
  lib/
    utils.ts                   wa.me links, image validation, formatHourRow, paragraphs…
    handoff.ts                 beginSubscriptionHandoff() / applyVerifiedSubscription() seam
  chooser/DesignChooser.tsx    Auto-rotating selector (scaled live renders)
  studio/PreviewStudio.tsx     Chrome, design pills, device frames, entitlement chip
  components/
    EditorPanel.tsx            Business / Services / Photos & logo tabs
    uploaders.tsx              Logo + photo uploaders (validate, replace, remove, reorder)
    UpgradeModal.tsx           Honest upgrade/handoff dialog incl. the reported plan-limit gap
    kit.tsx                    BrandMark, SamplePill, WhatsAppAction
    SmartImage.tsx             Shimmer→fade image
  templates/registry.ts        Six families: id, name, strategy, blurb, palette, component
  templates/<family>/…         Velvet, Forge, Savanna, Praxis, Market, Vital
  assets/samples/              Bundled demo photography (inlined at build)
```

## 5. Entitlement & persistence model (acceptance rules)

**Free tier (this build):** explore designs, edit all business fields, change logo,
upload/replace/remove/reorder up to **6 of your own photos**. Capacity is enforced inside
`addPhotos` (context action) via `deriveEntitlement(null) → 6`; the uploader merely surfaces it.
Bundled sample photos are placeholders and never consume the allowance — removing them is free.

**Paid tier:** more than 6 photos requires a `VerifiedSubscriptionSession` with
`verifiedByServer: true` and a numeric `photoLimit` from the platform's plan catalogue.
Opening the editor, starting checkout, or any UI action cannot manufacture this.
The same `assertPhotoCapacity(session, count)` function is exported for the platform API to
re-run server-side on every mutation.

**Preservation:** photos, logo, business details and selected design are context-owned and
never reset on template switches or entitlement changes. `PaidEditorBoot.previewContent`
documents that the paid editor boots *from* the preview content.

**Draft persistence honesty:** text fields persist in `sessionStorage` (this tab only, labelled).
Photo/logo binaries are intentionally not persisted — browser quotas would discard them
silently, and we never silently lose user content.

## 6. Acceptance criteria status report

> Inspection performed first (grep for paystack/billing/subscription/plan/vercel/payment).
> **Found:** only this prototype's own placeholder seam. **No existing platform code in this
> workspace** — no Paystack integration, no plan catalogue, no server, no Vercel config.

| # | Requirement | Status | Detail |
|---|-------------|--------|--------|
| 1 | Free: explore, preview, logo, ≤6 photos | ✅ Implemented | Selector + studio; 6 enforced in `addPhotos` via entitlement gate |
| 2 | Paid: >6 photos within configured plan limit | ⚠️ Blocked — **no paid limit exists; awaiting plan catalogue + approval** | Gate supports it; `resolvePaidPhotoLimit()` returns null; nothing invented |
| 3 | Edit details after creation (name, tagline, description, services, prices, contacts, open/close times, closed days) | ✅ Implemented (editor scope = preview content) | Structured `HourRow {day, open, close, closed}` + full field set |
| 4 | Industry-specific editable fields, no fake systems | ✅ Implemented | Services/categories/prices, credentials (honesty module), standards labels; no bookings |
| 5 | Add/replace/delete/**reorder** photos; preserve content across template switches | ✅ Implemented | Arrow reorder in photo tray; context-owned content |
| 6 | Persist edits securely; show in preview & published output | ⚠️ Partial (prototype) | Text draft in sessionStorage (labelled); server-side persistence requires platform DB — out of scope for static build |
| 7 | Server-side entitlement enforcement | ⚠️ Gate implemented & exported; **server binding requires the platform API**, absent here | `assertPhotoCapacity()` is the shared pure check |
| 8 | Inspect first; reuse; avoid duplicates | ✅ Done | Single entitlement module; handoff re-uses its session type |
| 9 | Test free & paid access, persistence, mobile layouts, industry fields | ⚠️ Partially testable here | Free path fully exercisable; paid path has no checkout/session source in this workspace — see §7 test plan |
| 10 | Protect auth/payments/billing/data/SEO/publishing; no Production changes | ✅ Compliant | None touched; none exist in this repo; modal/seam are the only billing-facing surface |

## 7. What needs approval / platform access next

1. **Paid photo plan limits** — none defined anywhere in this build. We will NOT ship a number
   without the plan catalogue and explicit approval.
2. **Server enforcement binding** — wire `assertPhotoCapacity` into the platform API’s photo
   mutations (Paystack verification flow unchanged).
3. **Vercel Preview free/paid testing** — requires the deployed platform with real checkout and
   sessions; cannot be executed from this static workspace. Test plan ready:
   - Free account: 7th photo rejected client-side *and* (post-integration) 402/403 API-side.
   - Paid account (verified session): uploads succeed up to plan limit; limit+1 rejected.
   - Start checkout → return without verification → still 6 (status quo check).
   - Switching templates mid-edit preserves photos/logo/details/design in both tiers.

## 8. Integrating a template into an existing Next.js app

Each family is self-contained. Example with Velvet:

1. Copy `src/templates/velvet/VelvetTemplate.tsx`, `src/components/kit.tsx`,
   `src/components/SmartImage.tsx` (or swap for `next/image`), and `src/types.ts` shapes.
2. Provide props `{ business, logo, photos, onEditRequest }` from your CMS/database.
3. Add family fonts (see `src/index.css`) via `next/font/google`, mapped to `font-velvet`, etc.
4. Templates use container queries (`@container`, `@md:`, `cqw`). Tailwind v4 supports these;
   for v3 add `@tailwindcss/container-queries`, or swap `@md:`→`md:` for viewport breakpoints.
5. Links: `wa.me`, `tel:`, `mailto:` helpers (`src/lib/utils.ts`); Google Maps uses the no-key
   `maps/search/?api=1&query=` scheme.
6. Capacity: editor/API must call `deriveEntitlement()` / `assertPhotoCapacity()` from
   `src/config/entitlements.ts`; sessions come from the platform's server verification only.

Next industry: duplicate `data/barberPack.ts`, regenerate sample imagery (no-people rule),
reuse selector/studio/registry unchanged.

## 9. Limitations (by design, for the prototype)

- No server-side persistence, accounts or publishing in this static build; no payment processing.
- Photos are memory-resident data URLs; real storage belongs to the platform editor.
- Paid expansion is intentionally inert until the platform supplies verified sessions + limits.
- Templates render single-page compositions; multi-page is a platform concern.
- Google Fonts load at runtime; offline, system fallbacks apply.

## 10. Concise test checklist

**Selector**
- [ ] Rotates ~6.5s with progress bar; prev/next/pills pause it; pause/play toggles.
- [ ] Hover/focus/touch pauses; reduced-motion disables rotation & slide animation entirely.

**Free tier**
- [ ] Edit every field incl. structured hours (open/close/Closed) — all six designs update live.
- [ ] Logo upload/replace/remove with validation errors (type, >4 MB).
- [ ] Photos: add ≤6 of your own (samples don't count), replace, remove, reorder arrows; 7th own photo rejected with entitlement message.
- [ ] Switching templates preserves everything; reload keeps text draft only (label states so).
- [ ] Praxis empty state when 0 photos; WhatsApp placeholders when number missing.
- [ ] Mobile (390px) and desktop frames render all six without overflow.

**Paid tier (blocked: needs plan limits + platform session)**
- [ ] After server-verified subscription: photo limit expands to plan value; content preserved.
- [ ] Limit+1 rejected server-side even if the UI is bypassed.
- [ ] Checkout started but unverified → still 6.

**Honesty rules**
- [ ] "Sample" labels on prices/photos/story; no reviews/ratings/awards anywhere.
- [ ] Enquiry form states "not a confirmed booking"; upgrade modal never opens paid capacity.

**Build**
- [ ] `npm run build` succeeds (single-file output, images inlined).

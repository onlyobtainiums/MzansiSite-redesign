/**
 * ENTITLEMENTS — the single gate for free-vs-paid capability.
 *
 * Rules implemented here (per MzansiSite acceptance criteria):
 *  • Free preview: exactly FREE_PREVIEW_PHOTO_LIMIT (6) business photos.
 *  • More than 6 photos requires a server-verified subscription session:
 *      - session.verifiedByServer must be true (set by the platform API after
 *        Paystack confirms payment — never by the browser, a URL flag, or
 *        the act of opening checkout/the editor), and
 *      - session.photoLimit must be a real number supplied by the platform's
 *        plan catalogue.
 *  • NO paid photo limit is defined anywhere in this implementation, and the
 *    acceptance criteria forbid inventing one. Until the platform supplies a
 *    configured plan limit, deriveEntitlement() can therefore only ever
 *    return the free tier. (GAP REPORTED — needs platform plan catalogue +
 *    approval before any number is established.)
 *
 * Production: the platform's API must call deriveEntitlement() (or the same
 * logic against the same session shape) on every upload/list mutation, so
 * entitlements are enforced server-side — never merely by hiding UI.
 */

export interface VerifiedSubscriptionSession {
  plan: string;
  photoLimit: number;
  token: string;
  /** True ONLY when set by the platform after server-side payment verification. */
  verifiedByServer: true;
}

export type Entitlement =
  | { kind: 'free-preview'; photoLimit: number; canPublish: false }
  | { kind: 'paid'; photoLimit: number; canPublish: true; plan: string };

export const FREE_PREVIEW_PHOTO_LIMIT = 6;

/**
 * The one decision-maker. Anything else (UI labels, uploaders, server
 * endpoints) must read from here, never re-implement the rule.
 */
export function deriveEntitlement(session: VerifiedSubscriptionSession | null): Entitlement {
  if (
    session &&
    session.verifiedByServer === true &&
    Number.isFinite(session.photoLimit) &&
    session.photoLimit > FREE_PREVIEW_PHOTO_LIMIT
  ) {
    return { kind: 'paid', photoLimit: session.photoLimit, canPublish: true, plan: session.plan };
  }
  // Default: free preview. Opening the editor or starting checkout must not
  // get anyone past this line.
  return { kind: 'free-preview', photoLimit: FREE_PREVIEW_PHOTO_LIMIT, canPublish: false };
}

/**
 * Server-side guard to be reused by the platform API on photo mutations.
 * `currentPhotoCount` must be the count of the user's OWN uploads —
 * bundled sample placeholders never count against the allowance.
 */
export function assertPhotoCapacity(
  session: VerifiedSubscriptionSession | null,
  currentPhotoCount: number,
): { ok: true; limit: number } | { ok: false; limit: number; reason: string } {
  const ent = deriveEntitlement(session);
  if (currentPhotoCount >= ent.photoLimit) {
    return {
      ok: false,
      limit: ent.photoLimit,
      reason:
        ent.kind === 'free-preview'
          ? `Free preview allows ${ent.photoLimit} photos. A verified subscription is required for more.`
          : `Your ${ent.plan} plan allows ${ent.photoLimit} photos.`,
    };
  }
  return { ok: true, limit: ent.photoLimit };
}

/**
 * Upload limits & validation constants.
 *
 * ENTITLEMENT NOTE: photo capacity is owned by src/config/entitlements.ts
 * (single source of truth — deriveEntitlement). Do not add a photo-count
 * constant here; that path must always flow through the entitlement gate.
 *
 * IMPORTANT (reported gap): no paid photo limit is defined in the plan
 * catalogue available to this build. Acceptance rules forbid inventing one —
 * the platform must supply plan limits before paid expansion is enabled.
 * resolvePaidPhotoLimit therefore returns null until the host injects config.
 */

export const PREVIEW_LOGO_LIMIT = 1;

/** Upload validation */
export const ACCEPTED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
export const MAX_IMAGE_BYTES = 4 * 1024 * 1024; // 4 MB per file

/**
 * Integration point for the paid editor: the host platform (after
 * server-verified billing) calls the editor with its configured limit.
 * Returns null until the plan catalogue is wired in.
 */
export type PlanSlug = string;
export function resolvePaidPhotoLimit(_plan: PlanSlug | null): number | null {
  return null; // awaiting platform plan catalogue — do not invent a number
}

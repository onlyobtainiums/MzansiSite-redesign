/**
 * Subscription handoff seam — the ONLY place the preview meets billing.
 *
 * Production contract (implemented by the host platform, not this prototype):
 *
 *  1. beginSubscriptionHandoff()
 *     Redirects to the platform's existing checkout (Paystack, unchanged).
 *
 *  2. The platform processes payment and verifies it SERVER-SIDE (Paystack
 *     webhook / verify endpoint). Only then does it mint a
 *     VerifiedSubscriptionSession with the plan's photoLimit from the plan
 *     catalogue.
 *
 *  3. The editor and the API both call deriveEntitlement(session)
 *     (src/config/entitlements.ts) on every photo mutation. A success URL
 *     parameter, an open editor, or a started checkout must never unlock
 *     anything.
 *
 *  Note (per acceptance criteria): no paid photo limit exists in the plan
 *  catalogue this deliverable was built against — none was invented here.
 *  The platform must supply plan limits before paid expansion goes live.
 */
import type { VerifiedSubscriptionSession } from '../config/entitlements';

export type { VerifiedSubscriptionSession };

export interface PaidEditorBoot {
  session: VerifiedSubscriptionSession;
  /** initial content carried over from the free preview — preserved, not reset */
  previewContent: unknown;
}

export function beginSubscriptionHandoff(): string {
  console.info(
    '[MzansiSite handoff] In production this redirects to the platform checkout and ' +
      'returns only after server-side verification. The prototype stops here by design.',
  );
  return 'Prototype boundary: checkout is handled by the MzansiSite platform (Paystack, unchanged). Nothing was charged and no paid feature was unlocked — expanded photo capacity requires a server-verified subscription.';
}

/** Host-platform entry point placeholder (never called in the prototype). */
export function applyVerifiedSubscription(_session: VerifiedSubscriptionSession): never {
  throw new Error('Subscriptions are verified by the MzansiSite platform, not by this prototype.');
}

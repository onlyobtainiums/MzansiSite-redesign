/**
 * Barber industry module — adapter over the EXISTING, unmodified Barber pack.
 */
import type { IndustryModule } from '../types';
import { freshSampleContent, SAMPLE_PHOTOS } from '../../data/barberPack';
import { TEMPLATES } from '../../templates/registry';

export const barberIndustry: IndustryModule = {
  id: 'barber',
  label: 'Barber',
  packKicker: 'Barber Template Pack · 6 designs',
  chooserHeadline: 'Six ways to put your barbershop online.',
  chooserIntro:
    'Every design is a real, working website — not a mockup. Pick one, add your details and photos in a free preview, and only pay when you’re ready to publish. Switching designs keeps everything you’ve typed.',
  imageryNote: 'Imagery rule: tools, chairs, interiors and products only — no people, faces, bodies or hands.',
  draftKey: 'mzansisite.draft.barber.v1',
  sampleBusiness: freshSampleContent,
  samplePhotos: SAMPLE_PHOTOS,
  templates: TEMPLATES,
};

/**
 * Industry module contract — the repeatable seam for 52+ industries.
 *
 * An "industry pack" = sample data + imagery + six family templates + labels.
 * The chooser, studio, editor and entitlement engine are industry-agnostic and
 * simply consume whatever module is active. Existing packs are never edited
 * when a new industry is added.
 */
import type { ComponentType } from 'react';
import type { BusinessData, PhotoItem, TemplateId, TemplateProps } from '../types';

export interface FamilyDef {
  id: TemplateId;
  name: string;
  strategy: string;
  blurb: string;
  chips: string[];
  component: ComponentType<TemplateProps>;
}

export interface IndustryModule {
  id: 'barber' | 'hair-salon' | (string & {});
  label: string;              // "Barber" / "Hair Salon"
  packKicker: string;         // chooser eyebrow, e.g. "Barber Template Pack · 6 designs"
  chooserHeadline: string;
  chooserIntro: string;
  /** declared imagery rules for this industry's sample/AI imagery */
  imageryNote: string;
  draftKey: string;           // per-industry sessionStorage draft key
  sampleBusiness: () => BusinessData;
  samplePhotos: PhotoItem[];
  templates: FamilyDef[];
}

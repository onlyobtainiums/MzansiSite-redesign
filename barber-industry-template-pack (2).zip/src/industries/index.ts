import type { IndustryModule } from './types';
import { barberIndustry } from './barber';
import { hairSalonIndustry } from './hair-salon';

export const INDUSTRIES: IndustryModule[] = [barberIndustry, hairSalonIndustry];
export const DEFAULT_INDUSTRY = 'hair-salon';

export const industryById = (id: string): IndustryModule =>
  INDUSTRIES.find((i) => i.id === id) ?? INDUSTRIES[0];

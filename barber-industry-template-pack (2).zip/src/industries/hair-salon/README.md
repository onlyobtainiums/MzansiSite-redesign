# Hair Salon Industry Pack — MzansiSite Studio (v1)

A second, parallel industry pack: six genuinely new designs under the same six family
directions, the same technical standards, and the same integration approach as the
Barber pack — **with zero modifications to the Barber pack**.

## What is genuinely Hair Salon (not a rename)

| Family   | Design direction | Hair-Salon identity & composition |
|----------|------------------|------------------------------------|
| Velvet   | Hero-first       | Deep plum & rose-gold editoriale with **arched frames**, italic serif accents, rounded "Come as you are" visit card |
| Forge    | Services-first   | Sheet-white menu with a **sticky category rail**, grouped panels (Cut & Style / Colour / Treatments / Texture), chartreuse accent |
| Savanna  | Trust-first      | Botanical calm: **first-visit guide** (consult → quote → basin care), station standards, strand-test note, honest credentials module |
| Praxis   | Gallery-first    | **Dark contact-sheet** look-book: "Frame 01" featured plate, numbered plates, champagne captions |
| Market   | About-first      | **A letter from the studio**: blush paper, sign-off, belief cards, tilted polaroid frames |
| Vital    | Enquiry-first    | **Hair consult form** — length / texture chips, goal field, service interest — drafted into one WhatsApp message (never a claimed booking) |

- **Sample business**: "Marula Gold Hair Studio", Parkhurst, Johannesburg — salon-typical
  hours (Monday + Sunday closed), 15 services across 4 salon categories, sample prices clearly labelled.
- **Industry-specific editables**: service categories for colour/treatments/texture, structured
  open/close/closed day fields (closed Mon & Sun in the sample), credentials (ships empty by design).

## Imagery rules (Islamic-values compliant)

Bundled sample imagery contains **no people, faces, bodies or hands** — interiors, styling
tools, towels and product shelves only. Two images are generated locally
(`assets/hero-interior.jpg`, `assets/tools-flatlay.jpg`, inlined at build); six are curated
people-free stock photographs referenced by CDN URL. The same rule is declared for imagery in
the chooser's honesty panel via `industry.imageryNote`, and applies to demo uploads.

## Structure (mirrors the Barber pack)

```
src/industries/hair-salon/
  index.ts                       IndustryModule (labels, imagery note, draft key, module assembly)
  data/hairSalonPack.ts          Labelled SAMPLE content (services, prices, hours, photos)
  templates/registry.ts          Six families: id, name, strategy, blurb, palette, component
  templates/<family>/<Family>Template.tsx   Velvet · Forge · Savanna · Praxis · Market · Vital
  assets/                        Locally generated imagery
  README.md                      This file
```

Loads through the shared, industry-agnostic machinery — unchanged for Arena integration:
`src/industries/types.ts` (module contract) → `src/industries/index.ts` (INDUSTRIES list) →
`App.tsx` selects the module → `StudioProvider` consumes it (content, per-industry draft key
`mzansisite.draft.hair-salon.v1`) → chooser/studio render `industry.templates`.

## Requirements parity with the Barber pack

Same rules and components apply — nothing duplicated: free preview = 6 **own** photos
(samples don't count) enforced by the context action via `deriveEntitlement`; paid expansion
only through a server-verified platform session; photo add/replace/remove/**reorder**; all
business fields editable incl. structured hours; tab-local text draft with honest photo
persistence copy; sample-content labelling; no invented reviews/awards/credentials; enquiry ≠
booking; responsive via container queries; reduced-motion respected. The paid photo limit
remains **undefined by design** — awaiting the platform plan catalogue (see root README §6–7).

## Adding industry #3

Copy `src/industries/hair-salon/` to `src/industries/<id>/`, replace:
(1) `data/<id>Pack.ts` sample content + imagery (respecting imagery rules),
(2) the six family components (new designs, same six directions),
(3) the module fields. Register in `src/industries/index.ts`. The Barber and Hair Salon packs
stay untouched.

## Verification checklist (pack-specific)

- [ ] Hair Salon is the default pack; Barber loads fully via the industry switcher (content intact).
- [ ] Each pack keeps its own draft (edit in Hair Salon, switch to Barber, switch back → salon text restored).
- [ ] All six salon designs render in the auto-rotating chooser and in mobile/desktop frames.
- [ ] Vital's consult form validates, composes length/texture/service/goal into the WhatsApp draft.
- [ ] Hours editor shows Monday + Sunday "Closed" across all six designs; time edits update live.
- [ ] No image in the pack depicts people (checked asset list + stock alt texts).
- [ ] `npm run build` succeeds — bundle includes both packs.

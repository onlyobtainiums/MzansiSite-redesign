import type { FamilyDef } from '../../types';
import VelvetTemplate from './velvet/VelvetTemplate';
import ForgeTemplate from './forge/ForgeTemplate';
import SavannaTemplate from './savanna/SavannaTemplate';
import PraxisTemplate from './praxis/PraxisTemplate';
import MarketTemplate from './market/MarketTemplate';
import VitalTemplate from './vital/VitalTemplate';

export const TEMPLATES: FamilyDef[] = [
  {
    id: 'velvet',
    name: 'Velvet',
    strategy: 'Hero-first',
    blurb: 'A cinematic plum opening — your studio name in soft serif, arched frames, then services and details.',
    chips: ['#251322', '#f6ede3', '#d8a18c'],
    component: VelvetTemplate,
  },
  {
    id: 'forge',
    name: 'Forge',
    strategy: 'Services-first',
    blurb: 'The full menu commands the page: a sticky category rail, grouped panels and plain mono prices.',
    chips: ['#f3f3ef', '#11151a', '#d9f73a'],
    component: ForgeTemplate,
  },
  {
    id: 'savanna',
    name: 'Savanna',
    strategy: 'Trust-first',
    blurb: 'Studio info, a first-visit guide and standards upfront. Credentials appear only when they are real.',
    chips: ['#edf3ec', '#234034', '#3d6650'],
    component: SavannaTemplate,
  },
  {
    id: 'praxis',
    name: 'Praxis',
    strategy: 'Gallery-first',
    blurb: 'A dark contact-sheet look-book: numbered plates, one featured frame, honest empty states.',
    chips: ['#141414', '#efece6', '#e5cf9f'],
    component: PraxisTemplate,
  },
  {
    id: 'market',
    name: 'Market',
    strategy: 'About-first',
    blurb: 'A letter from the studio: your story in serif, values, polaroids, then the menu and directions.',
    chips: ['#faf1ea', '#3b2417', '#e0703f'],
    component: MarketTemplate,
  },
  {
    id: 'vital',
    name: 'Vital',
    strategy: 'Enquiry-first',
    blurb: 'A hair consult leads: length, texture and goals drafted into one WhatsApp message.',
    chips: ['#f6f1ea', '#332217', '#1faf57'],
    component: VitalTemplate,
  },
];

/**
 * HAIR SALON · SAVANNA — trust-first (salon edition).
 * Botanical calm: leads with studio information, a first-visit guide and
 * service standards. Credentials appear only when genuinely supplied.
 */
import {
  BadgeCheck, Clock, Droplets, Leaf, Mail, MapPin, MessageCircle, Navigation, Phone, ShieldCheck, Sparkles,
} from 'lucide-react';
import type { TemplateProps } from '../../../../types';
import { SmartImage } from '../../../../components/SmartImage';
import { BrandMark, SamplePill, WhatsAppAction } from '../../../../components/kit';
import { formatHourRow, mailLink, telLink } from '../../../../lib/utils';

const LEAF = '#3d6650';
const PINE = '#234034';

const GUIDE = [
  { n: '01', t: 'Consultation first', d: 'We talk through your hair history, texture and goals before anything touches your hair.' },
  { n: '02', t: 'A quoted price, agreed', d: 'You hear the full price — including any extra product — before the service begins.' },
  { n: '03', t: 'Care at the basin', d: 'We finish with honest guidance on upkeep, not a shelf of products you don’t need.' },
];

const STANDARDS = [
  { icon: ShieldCheck, text: 'Sanitised tools and fresh towels for every guest' },
  { icon: Droplets, text: 'Colour strand-tests whenever your hair history suggests caution' },
  { icon: Sparkles, text: 'No pressure retail — recommendations stay honest' },
  { icon: Clock, text: 'Realistic timing: we book unhurried chairs and say so if we run late' },
];

export default function SavannaTemplate({ business: b, logo, photos, onEditRequest }: TemplateProps) {
  const name = b.name || 'Your Hair Studio';
  const feature = photos[2] ?? photos[0];

  return (
    <div className="@container bg-[#edf3ec] font-savanna-sans text-[#234034]">
      {/* ------------------------------------------------ header */}
      <header className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-5 pt-7 @md:px-8">
        <div className="flex items-center gap-3">
          <BrandMark logo={logo} name={name} className="h-11 w-11 text-xs" />
          <div className="leading-tight">
            <p className="font-savanna text-lg font-semibold">{name}</p>
            <p className="text-[11px] font-bold uppercase tracking-[0.22em]" style={{ color: LEAF }}>{b.area || 'Your area'}</p>
          </div>
        </div>
        <nav className="flex flex-wrap items-center gap-5 text-[12px] font-bold uppercase tracking-[0.16em] text-[#234034]/65">
          <a href="#hsv-guide" className="hover:text-[#5d8a70]">First visit</a>
          <a href="#hsv-standards" className="hover:text-[#5d8a70]">Standards</a>
          <a href="#hsv-services" className="hover:text-[#5d8a70]">Services</a>
        </nav>
      </header>

      {/* ------------------------------------------------ trust hero */}
      <section className="mx-auto grid max-w-6xl gap-10 px-5 py-12 @md:px-8 @md:py-16 @lg:grid-cols-[1.15fr_1fr] @lg:items-center">
        <div>
          <p className="mb-4 inline-flex items-center gap-2 rounded-full border border-[#3d6650]/30 bg-white/60 px-3 py-1 text-[11px] font-bold uppercase tracking-[0.2em]" style={{ color: LEAF }}>
            <Leaf className="h-3 w-3" /> An honest hair studio
          </p>
          <h1 className="font-savanna text-[clamp(2.1rem,5.2cqw,3.8rem)] font-semibold leading-[1.06]">
            Good hair days start with knowing what to expect.
          </h1>
          <p className="mt-5 max-w-[52ch] text-[15px] leading-relaxed text-[#234034]/75">
            {b.tagline || 'Add a line about how you run your studio.'} Here’s our studio information —
            hours, directions and exactly how a first visit works.
          </p>
          <div className="mt-8 flex flex-wrap gap-4">
            <WhatsAppAction
              whatsapp={b.whatsapp}
              message={`Hi ${name}, I'm planning my first visit.`}
              className="rounded-full bg-[#3d6650] px-6 py-3 text-sm font-bold text-white shadow-sm transition-transform hover:-translate-y-0.5"
            />
            <a href="#hsv-visit" className="inline-flex items-center gap-2 rounded-full border-2 border-[#234034]/60 px-6 py-3 text-sm font-bold transition-colors hover:bg-[#234034] hover:text-[#edf3ec]">
              Plan my visit
            </a>
          </div>
        </div>

        {/* studio information card */}
        <div className="rounded-2xl border border-[#234034]/10 bg-white p-6 shadow-[0_18px_50px_-24px_rgba(35,64,52,0.4)] @md:p-8">
          <div className="flex items-center gap-4 border-b border-dashed border-[#234034]/20 pb-5">
            <BrandMark logo={logo} name={name} className="h-14 w-14 text-sm" />
            <div>
              <p className="font-savanna text-xl font-semibold">{name}</p>
              <p className="text-[12px] font-bold uppercase tracking-[0.18em]" style={{ color: LEAF }}>{b.area}</p>
            </div>
          </div>
          <dl className="mt-5 space-y-4 text-sm">
            <Info icon={MapPin} label="Address" value={`${b.address || 'Add your address'}${b.area ? `, ${b.area}` : ''}`} />
            <Info icon={Phone} label="Phone" value={b.phone || 'Not added yet'} href={b.phone ? telLink(b.phone) : undefined} />
            <Info icon={Mail} label="Email" value={b.email || 'Not added yet'} href={b.email ? mailLink(b.email) : undefined} />
            <Info icon={MessageCircle} label="WhatsApp" value={b.whatsapp || 'Not added yet'} />
          </dl>
          <p className="mt-6 rounded-xl bg-[#edf3ec] px-4 py-3 text-[12px] leading-relaxed text-[#234034]/70">
            New here? Send a WhatsApp with your hair goals — we’ll suggest the right service and time before you travel.
          </p>
        </div>
      </section>

      {/* ------------------------------------------------ first-visit guide */}
      <section id="hsv-guide" className="bg-[#e2ecdf]">
        <div className="mx-auto max-w-6xl px-5 py-14 @md:px-8">
          <div className="mb-8 flex flex-wrap items-center gap-3">
            <h2 className="font-savanna text-[clamp(1.5rem,3.2cqw,2.2rem)] font-semibold">Your first visit, step by step</h2>
            <SamplePill label="Sample guide" />
          </div>
          <div className="grid gap-5 @md:grid-cols-3">
            {GUIDE.map((g) => (
              <div key={g.n} className="rounded-2xl bg-white p-6 shadow-sm">
                <p className="font-savanna text-3xl font-semibold" style={{ color: LEAF }}>{g.n}</p>
                <h3 className="mt-3 font-savanna text-lg font-semibold">{g.t}</h3>
                <p className="mt-2 text-sm leading-relaxed text-[#234034]/70">{g.d}</p>
              </div>
            ))}
          </div>
          <p className="mt-4 text-[12px] text-[#234034]/55">Replace this sample guide with your studio’s real first-visit process in the editor.</p>
        </div>
      </section>

      {/* ------------------------------------------------ standards + credentials */}
      <section id="hsv-standards" className="mx-auto grid max-w-6xl gap-10 px-5 py-14 @md:px-8 @md:py-20 @lg:grid-cols-2">
        <div>
          <div className="mb-6 flex items-center gap-3">
            <h2 className="font-savanna text-[clamp(1.5rem,3.2cqw,2.2rem)] font-semibold">Standards at the station</h2>
            <SamplePill label="Sample list" />
          </div>
          <ul className="space-y-4">
            {STANDARDS.map((s, i) => (
              <li key={i} className="flex items-start gap-4 rounded-2xl border border-[#234034]/10 bg-white px-5 py-4">
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full" style={{ background: '#edf3ec', color: LEAF }}>
                  <s.icon className="h-4.5 w-4.5" aria-hidden />
                </span>
                <p className="pt-2 text-[15px] font-semibold">{s.text}</p>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h2 className="mb-6 font-savanna text-[clamp(1.5rem,3.2cqw,2.2rem)] font-semibold">Training &amp; credentials</h2>
          {b.credentials.length > 0 ? (
            <ul className="space-y-3">
              {b.credentials.map((c, i) => (
                <li key={i} className="flex items-center gap-3 rounded-xl bg-white px-5 py-4 text-[15px] font-semibold shadow-sm">
                  <BadgeCheck className="h-5 w-5 shrink-0" style={{ color: LEAF }} /> {c}
                </li>
              ))}
            </ul>
          ) : (
            <div className="rounded-2xl border-2 border-dashed border-[#3d6650]/40 bg-white/60 p-8">
              <BadgeCheck className="h-8 w-8" style={{ color: LEAF }} aria-hidden />
              <p className="mt-3 font-savanna text-lg font-semibold">Nothing added yet — and that&apos;s honest.</p>
              <p className="mt-2 text-sm leading-relaxed text-[#234034]/70">
                This design only shows real training, certificates or product-brand accreditations that you add
                yourself. It never invents them, and it never invents “five-star” reviews.
              </p>
              <button type="button" onClick={() => onEditRequest?.('business')}
                className="mt-5 rounded-full px-5 py-2.5 text-sm font-bold text-white" style={{ background: LEAF }}>
                Add real credentials in the editor
              </button>
            </div>
          )}
          {feature && (
            <figure className="mt-8">
              <SmartImage src={feature.src} alt={feature.alt} className="aspect-[16/10] w-full rounded-2xl" />
              <figcaption className="mt-2 flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.18em] text-[#234034]/55">
                {feature.alt} {feature.sample && <SamplePill label="Sample photo" />}
              </figcaption>
            </figure>
          )}
        </div>
      </section>

      {/* ------------------------------------------------ plan your visit */}
      <section id="hsv-visit" className="bg-white">
        <div className="mx-auto max-w-6xl px-5 py-14 @md:px-8">
          <h2 className="font-savanna text-[clamp(1.5rem,3.2cqw,2.2rem)] font-semibold">Plan your visit</h2>
          <div className="mt-8 grid gap-5 @md:grid-cols-3">
            <div className="rounded-2xl bg-[#edf3ec] p-6">
              <p className="mb-4 flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-[0.22em]" style={{ color: LEAF }}>
                <Clock className="h-4 w-4" /> Studio hours
              </p>
              <ul className="space-y-3">
                {b.hours.map((h) => (
                  <li key={h.id} className="flex justify-between gap-4 border-b border-[#234034]/8 pb-3 text-sm last:border-0 last:pb-0">
                    <span className="font-semibold">{h.label}</span>
                    <span className="text-[#234034]/70">{h.closed ? <em>Closed</em> : formatHourRow(h)}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="rounded-2xl bg-[#edf3ec] p-6">
              <p className="mb-4 flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-[0.22em]" style={{ color: LEAF }}>
                <MapPin className="h-4 w-4" /> Where we are
              </p>
              <p className="font-savanna text-lg font-semibold">{b.address || 'Add your address'}</p>
              <p className="text-sm text-[#234034]/70">{b.area || 'Your area'}</p>
              <a href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${b.address} ${b.area}`)}`}
                target="_blank" rel="noreferrer"
                className="mt-4 inline-flex items-center gap-2 text-sm font-bold underline decoration-[#3d6650] decoration-2 underline-offset-4">
                <Navigation className="h-3.5 w-3.5" /> Get directions
              </a>
            </div>
            <div className="rounded-2xl p-6 text-white" style={{ background: PINE }}>
              <p className="mb-4 flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-[0.22em] text-white/70">
                <MessageCircle className="h-4 w-4" /> Ask us anything
              </p>
              <p className="text-sm leading-relaxed text-white/85">
                Colour goals, texture questions or first-visit nerves — a message is the easiest start.
              </p>
              <WhatsAppAction whatsapp={b.whatsapp} message={`Hi ${name}, a quick question about a hair service.`}
                className="mt-5 inline-flex rounded-full bg-white px-5 py-2.5 text-sm font-extrabold" />
            </div>
          </div>
        </div>
      </section>

      {/* ------------------------------------------------ services summary */}
      <section id="hsv-services" className="mx-auto max-w-6xl px-5 py-14 @md:px-8">
        <div className="mb-8 flex flex-wrap items-center gap-3">
          <h2 className="font-savanna text-[clamp(1.5rem,3.2cqw,2.2rem)] font-semibold">What we offer</h2>
          <SamplePill label="Sample prices" />
        </div>
        <div className="grid gap-x-12 @md:grid-cols-2">
          {b.services.map((s) => (
            <div key={s.id} className="flex items-baseline justify-between gap-4 border-b border-[#234034]/10 py-3.5">
              <p className="text-[15px] font-semibold">{s.name}
                <span className="ml-2 text-[11px] font-bold uppercase tracking-[0.14em] text-[#234034]/45">{s.category}</span>
              </p>
              <p className="font-savanna text-lg font-semibold" style={{ color: LEAF }}>{s.price}</p>
            </div>
          ))}
          {b.services.length === 0 && (
            <button type="button" onClick={() => onEditRequest?.('services')}
              className="col-span-full rounded-xl border-2 border-dashed border-[#234034]/25 py-10 text-sm font-bold text-[#234034]/60">
              Add your services in the editor
            </button>
          )}
        </div>
      </section>

      <footer className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-5 py-8 text-[11px] font-bold uppercase tracking-[0.18em] text-[#234034]/50 @md:px-8">
        <span>{name} · {b.area}</span>
        <span>Design: Savanna · MzansiSite demo</span>
      </footer>
    </div>
  );
}

function Info({ icon: Icon, label, value, href }: { icon: React.ComponentType<{ className?: string }>; label: string; value: string; href?: string }) {
  return (
    <div className="flex items-start gap-3">
      <span className="mt-0.5" style={{ color: LEAF }}><Icon className="h-4 w-4 shrink-0" /></span>
      <div>
        <dt className="text-[10px] font-extrabold uppercase tracking-[0.2em] text-[#234034]/50">{label}</dt>
        <dd className="text-[15px] font-semibold">
          {href ? <a className="underline-offset-2 hover:underline" href={href}>{value}</a> : value}
        </dd>
      </div>
    </div>
  );
}

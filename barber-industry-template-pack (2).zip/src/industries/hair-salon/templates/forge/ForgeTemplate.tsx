/**
 * HAIR SALON · FORGE — services-first (salon edition).
 * The menu leads with a sticky category rail and grouped service panels.
 * Sheet-white, ink, and one chartreuse accent; prices in mono.
 */
import { useMemo, useState } from 'react';
import { ArrowUpRight, Clock3, Leaf, Mail, MapPin, Phone } from 'lucide-react';
import { cn } from '../../../../utils/cn';
import type { TemplateProps } from '../../../../types';
import { SmartImage } from '../../../../components/SmartImage';
import { BrandMark, SamplePill, WhatsAppAction } from '../../../../components/kit';
import { formatHourRow, mailLink, telLink } from '../../../../lib/utils';

const LIME = '#d9f73a';
const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-');

export default function ForgeTemplate({ business: b, logo, photos, onEditRequest }: TemplateProps) {
  const name = b.name || 'Your Hair Studio';
  const groups = useMemo(() => {
    const map = new Map<string, typeof b.services>();
    for (const s of b.services) {
      const key = s.category || 'Other';
      map.set(key, [...(map.get(key) ?? []), s]);
    }
    return [...map.entries()];
  }, [b.services]);
  const [active, setActive] = useState<string>(groups[0]?.[0] ?? '');
  const openDay = b.hours.find((h) => !h.closed);

  return (
    <div className="@container bg-[#f3f3ef] font-forge text-[#11151a]">
      {/* ------------------------------------------------ utility bar */}
      <div className="flex flex-wrap items-center justify-between gap-x-6 gap-y-1 bg-[#11151a] px-5 py-2.5 text-[11px] font-medium uppercase tracking-[0.18em] text-[#f3f3ef]/85 @md:px-10">
        <span className="flex items-center gap-2">
          <span className="inline-block h-2 w-2 rounded-full" style={{ background: LIME }} />
          Colour consults &amp; enquiries
        </span>
        <span className="hidden @sm:inline">{openDay ? `${openDay.label} · ${formatHourRow(openDay)}` : 'Add opening hours'}</span>
        <a href="#hf-menu" className="underline decoration-[#d9f73a] decoration-2 underline-offset-4 hover:text-white">Service menu</a>
      </div>

      {/* ------------------------------------------------ masthead */}
      <header className="border-b-2 border-[#11151a] px-5 pb-8 pt-10 @md:px-10 @md:pt-14">
        <div className="flex flex-wrap items-start justify-between gap-6">
          <div className="min-w-0">
            <p className="mb-3 flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.3em] text-[#11151a]/55">
              <Leaf className="h-3.5 w-3.5" aria-hidden /> Hair studio — {b.area || 'South Africa'}
            </p>
            <h1 className="text-[clamp(2.3rem,7.2cqw,5.2rem)] font-extrabold uppercase leading-[0.92] tracking-[-0.02em]">
              {name}
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <p className="max-w-[26ch] text-right text-sm font-medium leading-snug text-[#11151a]/65 @max-md:text-left">
              {b.tagline || 'Add your studio’s one-liner in the editor.'}
            </p>
            <BrandMark logo={logo} name={name} className="h-14 w-14 rounded-2xl border-2 text-sm" />
          </div>
        </div>
      </header>

      {/* ------------------------------------------------ the menu */}
      <main id="hf-menu" className="px-5 py-12 @md:px-10 @md:py-16">
        <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="font-prices text-[12px] font-semibold uppercase tracking-[0.3em] text-[#11151a]/50">The full menu</p>
            <h2 className="mt-2 text-[clamp(1.7rem,4cqw,2.8rem)] font-extrabold uppercase leading-none">Services &amp; Prices</h2>
          </div>
          <SamplePill label="Sample menu &amp; prices" />
        </div>

        {groups.length === 0 ? (
          <button type="button" onClick={() => onEditRequest?.('services')}
            className="w-full border-2 border-dashed border-[#11151a]/40 px-6 py-14 text-center text-sm font-semibold uppercase tracking-[0.14em] text-[#11151a]/60 hover:border-[#11151a]">
            No services yet — add your menu in the editor
          </button>
        ) : (
          <div className="grid items-start gap-8 @lg:grid-cols-[220px_1fr]">
            {/* sticky category rail */}
            <nav className="flex flex-wrap gap-2 @lg:sticky @lg:top-4 @lg:flex-col" aria-label="Menu categories">
              {groups.map(([cat, items]) => (
                <button
                  key={cat}
                  onClick={() => {
                    setActive(cat);
                    document.getElementById(`hf-${slug(cat)}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                  }}
                  className={cn(
                    'flex items-center justify-between gap-3 border-2 border-[#11151a] px-4 py-2.5 text-left text-[12px] font-bold uppercase tracking-[0.12em] transition-colors',
                    active === cat ? 'bg-[#11151a] text-[#d9f73a]' : 'hover:bg-[#11151a]/10',
                  )}
                >
                  {cat}
                  <span className={cn('font-prices text-[11px]', active === cat ? 'text-[#f3f3ef]/70' : 'text-[#11151a]/50')}>
                    {items.length}
                  </span>
                </button>
              ))}
              <div className="mt-2 hidden border-t-2 border-[#11151a] pt-4 text-[11.5px] font-semibold leading-relaxed text-[#11151a]/60 @lg:block">
                Colour &amp; chemical work always starts with a consultation and a quoted price — never a surprise at the till.
              </div>
            </nav>

            {/* grouped panels */}
            <div className="space-y-8">
              {groups.map(([cat, items], gi) => (
                <section key={cat} id={`hf-${slug(cat)}`} className="scroll-mt-4 border-2 border-[#11151a] bg-white">
                  <header className="flex items-center justify-between border-b-2 border-[#11151a] bg-[#f3f3ef] px-5 py-3">
                    <h3 className="text-[13px] font-extrabold uppercase tracking-[0.2em]">
                      {String(gi + 1).padStart(2, '0')} · {cat}
                    </h3>
                    <span className="font-prices text-[11px] font-semibold text-[#11151a]/50">{items.length} services</span>
                  </header>
                  <ol className="px-5">
                    {items.map((s) => (
                      <li key={s.id} className="border-b border-[#11151a]/12 py-4 last:border-0">
                        <div className="flex items-baseline gap-3">
                          <h4 className="text-[15px] font-bold uppercase tracking-[0.04em]">{s.name || 'Untitled service'}</h4>
                          <span className="mz-leader mx-1 flex-1" aria-hidden />
                          <span className="font-prices text-lg font-semibold">{s.price || '—'}</span>
                        </div>
                        {s.description && <p className="mt-1 max-w-[54ch] text-[13px] leading-relaxed text-[#11151a]/60">{s.description}</p>}
                      </li>
                    ))}
                  </ol>
                </section>
              ))}
            </div>
          </div>
        )}

        {/* enquiry band */}
        <div className="mt-14 flex flex-wrap items-center justify-between gap-6 border-2 border-[#11151a] bg-[#11151a] px-6 py-8 text-[#f3f3ef] @md:px-10">
          <div>
            <p className="font-prices text-[11px] uppercase tracking-[0.3em] text-[#f3f3ef]/55">Not sure what you need?</p>
            <p className="mt-1 text-xl font-extrabold uppercase">Send us your hair goals — we’ll advise honestly.</p>
            <p className="mt-1 text-[12px] text-[#f3f3ef]/55">An enquiry isn’t an appointment until the studio confirms one with you.</p>
          </div>
          <WhatsAppAction
            whatsapp={b.whatsapp}
            message={`Hi ${name}, I'd like some advice on a hair service.`}
            label="Enquire on WhatsApp"
            className="bg-[#d9f73a] px-6 py-3.5 text-[13px] font-extrabold uppercase tracking-[0.16em] text-[#11151a] transition-transform hover:-translate-y-0.5"
          />
        </div>
      </main>

      {/* ------------------------------------------------ studio cards */}
      <section className="grid gap-px border-y-2 border-[#11151a] bg-[#11151a] @md:grid-cols-3">
        <Card icon={Clock3} title="Hours">
          <ul className="space-y-2">
            {b.hours.map((h) => (
              <li key={h.id} className="flex justify-between gap-4 font-prices text-[13px]">
                <span className="text-[#11151a]/55">{h.label}</span>
                <span className="font-semibold">{h.closed ? 'Closed' : formatHourRow(h)}</span>
              </li>
            ))}
          </ul>
        </Card>
        <Card icon={MapPin} title="Find us">
          <p className="text-sm font-semibold">{b.address || 'Add your address'}</p>
          <p className="text-sm text-[#11151a]/60">{b.area || 'Your area'}</p>
          {b.phone && (
            <a href={telLink(b.phone)} className="mt-3 inline-flex items-center gap-2 text-sm font-bold underline decoration-[#d9f73a] decoration-2 underline-offset-4">
              <Phone className="h-3.5 w-3.5" /> {b.phone}
            </a>
          )}
        </Card>
        <Card icon={Mail} title="Enquiries">
          <p className="text-sm leading-relaxed text-[#11151a]/65">
            WhatsApp or email about colour goals, treatments or occasion styling — we reply during studio hours.
          </p>
          {b.email && (
            <a href={mailLink(b.email)} className="mt-3 inline-flex items-center gap-2 text-sm font-bold underline decoration-[#d9f73a] decoration-2 underline-offset-4">
              {b.email} <ArrowUpRight className="h-3.5 w-3.5" />
            </a>
          )}
        </Card>
      </section>

      {/* ------------------------------------------------ photo strip */}
      {photos.length > 0 && (
        <section className="px-5 py-12 @md:px-10">
          <div className="mb-5 flex items-center justify-between">
            <p className="font-prices text-[11px] font-semibold uppercase tracking-[0.3em] text-[#11151a]/50">Inside the studio</p>
            {photos.some((p) => p.sample) && <SamplePill label="Sample photos" />}
          </div>
          <div className="mz-frame-scroll flex snap-x gap-4 overflow-x-auto pb-3">
            {photos.map((p, i) => (
              <figure key={p.id} className="w-[240px] shrink-0 snap-start @md:w-[300px]">
                <SmartImage src={p.src} alt={p.alt} className="aspect-[4/3] w-full border-2 border-[#11151a]" />
                <figcaption className="mt-2 font-prices text-[11px] uppercase tracking-[0.14em] text-[#11151a]/55">
                  {String(i + 1).padStart(2, '0')} / {p.alt}
                </figcaption>
              </figure>
            ))}
          </div>
        </section>
      )}

      <footer className="flex flex-wrap items-center justify-between gap-3 border-t-2 border-[#11151a] px-5 py-6 text-[11px] font-bold uppercase tracking-[0.2em] text-[#11151a]/55 @md:px-10">
        <span>{name}</span>
        <span>Design: Forge · MzansiSite demo — prices shown are samples</span>
      </footer>
    </div>
  );
}

function Card({ icon: Icon, title, children }: { icon: React.ComponentType<{ className?: string }>; title: string; children: React.ReactNode }) {
  return (
    <div className="bg-[#f3f3ef] p-6 @md:p-8">
      <p className="mb-4 flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-[0.25em]">
        <Icon className="h-4 w-4" aria-hidden /> {title}
      </p>
      {children}
    </div>
  );
}

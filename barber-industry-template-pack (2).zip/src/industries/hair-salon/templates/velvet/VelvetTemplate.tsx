/**
 * HAIR SALON · VELVET — hero-first editorial (salon edition).
 * Deep plum, cream, rose-gold; arched frames and italic serif accents.
 * Leads with one cinematic interior frame, the studio name and a WhatsApp
 * enquiry, then a service edit, arched frames and visiting details.
 */
import { ArrowRight, Clock, ImagePlus, MapPin, Phone } from 'lucide-react';
import { cn } from '../../../../utils/cn';
import type { TemplateProps } from '../../../../types';
import { SmartImage } from '../../../../components/SmartImage';
import { BrandMark, SamplePill, WhatsAppAction } from '../../../../components/kit';
import { formatHourRow, telLink } from '../../../../lib/utils';

const ROSE = '#d8a18c';
const enquiry = (name: string) => `Hi ${name || 'there'}, I'd like to enquire about a hair appointment.`;

export default function VelvetTemplate({ business: b, logo, photos, onEditRequest }: TemplateProps) {
  const hero = photos[0];
  const frames = photos.slice(1, 4);
  const edit = b.services.slice(0, 6);
  const name = b.name || 'Your Hair Studio';
  const today = b.hours.find((h) => !h.closed);

  return (
    <div className="@container bg-[#251322] font-velvet text-[#f6ede3]">
      {/* ------------------------------------------------ header */}
      <header className="flex items-center justify-between px-6 pt-6 @md:px-12 @md:pt-9">
        <div className="flex items-center gap-3">
          <BrandMark logo={logo} name={name} className="h-10 w-10 text-xs" />
          <div className="leading-tight">
            <p className="text-[11px] uppercase tracking-[0.3em] text-[#f6ede3]/70">{name}</p>
            <p className="text-[10px] uppercase tracking-[0.2em] text-[#f6ede3]/45">{b.area || 'Your area'}</p>
          </div>
        </div>
        <nav className="hidden items-center gap-8 text-[11px] uppercase tracking-[0.25em] text-[#f6ede3]/65 @md:flex">
          <a className="hover:text-[#d8a18c]" href="#hvs-services">Services</a>
          <a className="hover:text-[#d8a18c]" href="#hvs-frames">Frames</a>
          <a className="hover:text-[#d8a18c]" href="#hvs-visit">Visit</a>
        </nav>
      </header>

      {/* ------------------------------------------------ hero */}
      <section className="relative grid items-center gap-10 px-6 pb-16 pt-10 @md:px-12 @lg:grid-cols-[1.05fr_0.95fr] @lg:pt-14">
        <div className="relative z-10">
          <p className="mb-5 flex items-center gap-3 text-[11px] uppercase tracking-[0.35em]" style={{ color: ROSE }}>
            <span className="h-px w-10" style={{ background: ROSE }} />
            Hair studio · {b.area || 'South Africa'}
          </p>
          <h1 className="max-w-[13ch] text-[clamp(2.9rem,8.6cqw,6.6rem)] font-light leading-[0.98]">
            {name.split(' ').map((w, i) => (
              <span key={i} className={cn(i === 1 && 'italic', i === 1 && 'text-[#d8a18c]')}>{w} </span>
            ))}
          </h1>
          <p className="mt-5 max-w-md font-['Inter'] text-[15px] leading-relaxed text-[#f6ede3]/75">
            {b.tagline || 'A short line about your studio goes here.'}
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-4">
            <WhatsAppAction
              whatsapp={b.whatsapp}
              message={enquiry(name)}
              className="bg-[#d8a18c] px-7 py-3.5 font-['Inter'] text-[13px] font-semibold uppercase tracking-[0.18em] text-[#251322] transition-transform hover:-translate-y-0.5"
            />
            <a
              href="#hvs-services"
              className="group inline-flex items-center gap-2 border border-[#f6ede3]/30 px-7 py-3.5 font-['Inter'] text-[13px] font-semibold uppercase tracking-[0.18em] transition-colors hover:border-[#d8a18c] hover:text-[#d8a18c]"
            >
              See the services <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </a>
          </div>
          <div className="mt-10 flex flex-wrap gap-x-8 gap-y-3 border-t border-[#f6ede3]/15 pt-6 font-['Inter'] text-[13px] text-[#f6ede3]/65">
            <span className="flex items-center gap-2"><MapPin className="h-3.5 w-3.5" style={{ color: ROSE }} />{b.address || 'Add your address'}, {b.area}</span>
            <span className="flex items-center gap-2"><Clock className="h-3.5 w-3.5" style={{ color: ROSE }} />{today ? `${today.label} ${formatHourRow(today)}` : 'Add opening hours'}</span>
            {b.phone && <a href={telLink(b.phone)} className="flex items-center gap-2 hover:text-[#d8a18c]"><Phone className="h-3.5 w-3.5" style={{ color: ROSE }} />{b.phone}</a>}
          </div>
        </div>

        <figure className="relative">
          {hero ? (
            <SmartImage src={hero.src} alt={hero.alt} eager className="aspect-[3/4] w-full rounded-t-[10rem] object-cover ring-1 ring-[#d8a18c]/40 @md:aspect-[4/5]" />
          ) : (
            <div className="grid aspect-[3/4] w-full place-items-center rounded-t-[10rem] bg-[#31182c] ring-1 ring-[#d8a18c]/40">
              <BrandMark logo={logo} name={name} className="h-24 w-24 text-2xl text-[#d8a18c]" />
            </div>
          )}
          <figcaption className="mt-3 flex items-center justify-between font-['Inter'] text-[11px] uppercase tracking-[0.2em] text-[#f6ede3]/50">
            <span>{hero?.alt || 'Add your signature interior shot'}</span>
            {hero?.sample && <SamplePill label="Sample" className="text-[#f6ede3]/60" />}
          </figcaption>
        </figure>
      </section>

      {/* ------------------------------------------------ service edit */}
      <section id="hvs-services" className="border-t border-[#f6ede3]/12 bg-[#2c1728] px-6 py-16 @md:px-12 @md:py-24">
        <div className="mb-10 flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-[11px] uppercase tracking-[0.35em]" style={{ color: ROSE }}>01 · The Service Edit</p>
            <h2 className="mt-3 text-[clamp(1.9rem,4.4cqw,3.3rem)] font-light leading-tight">
              Colour, cuts &amp; care — <em className="text-[#d8a18c]">priced plainly.</em>
            </h2>
          </div>
          <SamplePill label="Sample prices" className="text-[#f6ede3]/65" />
        </div>
        {edit.length === 0 ? (
          <EmptyNote onClick={() => onEditRequest?.('services')} label="No services yet — add your menu in the editor." />
        ) : (
          <ol className="grid gap-x-14 @lg:grid-cols-2">
            {edit.map((s, i) => (
              <li key={s.id} className="border-b border-[#f6ede3]/12 py-5">
                <div className="flex items-baseline gap-4">
                  <span className="text-xs italic tabular-nums" style={{ color: ROSE }}>{String(i + 1).padStart(2, '0')}</span>
                  <h3 className="flex-1 text-xl font-normal @md:text-2xl">{s.name || 'Untitled service'}</h3>
                  <span className="text-lg tabular-nums" style={{ color: ROSE }}>{s.price || '—'}</span>
                </div>
                {s.description && <p className="mt-1 pl-8 font-['Inter'] text-[13px] leading-relaxed text-[#f6ede3]/55">{s.description}</p>}
              </li>
            ))}
          </ol>
        )}
        <p className="mt-8 font-['Inter'] text-[12.5px] italic text-[#f6ede3]/50">
          Final quotes are always confirmed before any colour or chemical work begins.
        </p>
      </section>

      {/* ------------------------------------------------ frames */}
      <section id="hvs-frames" className="px-6 py-16 @md:px-12 @md:py-20">
        <div className="mb-10 flex items-end justify-between gap-4">
          <div>
            <p className="text-[11px] uppercase tracking-[0.35em]" style={{ color: ROSE }}>02 · Frames</p>
            <h2 className="mt-3 text-[clamp(1.6rem,3.4cqw,2.5rem)] font-light">Soft light, honest mirrors.</h2>
          </div>
          {photos.some((p) => p.sample) && <SamplePill label="Sample photos" className="text-[#f6ede3]/65" />}
        </div>
        {photos.length === 0 ? (
          <EmptyNote onClick={() => onEditRequest?.('media')} label="No photos yet — upload studio photos in the editor." />
        ) : (
          <div className="grid gap-5 @md:grid-cols-3">
            {frames.map((p, i) => (
              <figure key={p.id} className={cn(i === 1 && '@md:mt-12', i === 2 && '@md:mt-24')}>
                <SmartImage src={p.src} alt={p.alt} className="aspect-[3/4] w-full rounded-t-[8rem] object-cover" />
                <figcaption className="mt-3 flex items-center gap-2 font-['Inter'] text-[11px] uppercase tracking-[0.18em] text-[#f6ede3]/50">
                  <span style={{ color: ROSE }}>{String(i + 1).padStart(2, '0')}</span> {p.alt}
                  {p.sample && <SamplePill label="Sample" />}
                </figcaption>
              </figure>
            ))}
          </div>
        )}
      </section>

      {/* ------------------------------------------------ visit */}
      <section id="hvs-visit" className="mx-6 mb-16 overflow-hidden rounded-3xl bg-[#d8a18c] text-[#251322] @md:mx-12">
        <div className="grid @lg:grid-cols-2">
          <div className="px-7 py-12 @md:px-10">
            <p className="text-[11px] uppercase tracking-[0.35em] text-[#251322]/70">03 · Visit</p>
            <h2 className="mt-3 text-[clamp(1.9rem,4cqw,3rem)] font-light leading-tight">Come as you are.</h2>
            <div className="mt-6 space-y-3 font-['Inter'] text-[15px] font-medium text-[#251322]/85">
              <p className="flex gap-3"><MapPin className="mt-1 h-4 w-4 shrink-0" />{b.address || 'Add your address'}{b.area ? `, ${b.area}` : ''}</p>
              {b.phone && <a href={telLink(b.phone)} className="flex gap-3 underline-offset-4 hover:underline"><Phone className="mt-1 h-4 w-4 shrink-0" />{b.phone}</a>}
            </div>
            <WhatsAppAction
              whatsapp={b.whatsapp}
              message={enquiry(name)}
              label="Message the studio"
              className="mt-8 bg-[#251322] px-7 py-3.5 font-['Inter'] text-[13px] font-semibold uppercase tracking-[0.18em] text-[#d8a18c] transition-transform hover:-translate-y-0.5"
            />
          </div>
          <div className="border-t border-[#251322]/15 bg-[#cf937d] px-7 py-12 @lg:border-l @lg:border-t-0 @md:px-10">
            <p className="font-['Inter'] text-[11px] uppercase tracking-[0.3em] text-[#251322]/65">Studio hours</p>
            <ul className="mt-5 divide-y divide-[#251322]/15">
              {b.hours.map((h) => (
                <li key={h.id} className="flex items-baseline justify-between gap-6 py-3">
                  <span className="font-['Inter'] text-sm font-semibold text-[#251322]/70">{h.label}</span>
                  <span className="text-lg">{h.closed ? <em>Closed</em> : formatHourRow(h)}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <footer className="flex flex-wrap items-center justify-between gap-4 border-t border-[#f6ede3]/12 px-6 py-8 font-['Inter'] text-[11px] uppercase tracking-[0.2em] text-[#f6ede3]/45 @md:px-12">
        <span className="flex items-center gap-3"><BrandMark logo={logo} name={name} className="h-8 w-8 text-[10px]" />{name}</span>
        <span>Design: Velvet · MzansiSite demo — sample content until edited</span>
      </footer>
    </div>
  );
}

function EmptyNote({ label, onClick }: { label: string; onClick?: () => void }) {
  return (
    <button type="button" onClick={onClick}
      className="flex w-full items-center justify-center gap-3 border border-dashed border-[#f6ede3]/30 px-6 py-12 font-['Inter'] text-sm text-[#f6ede3]/60 transition-colors hover:border-[#d8a18c] hover:text-[#d8a18c]">
      <ImagePlus className="h-4 w-4" aria-hidden /> {label}
    </button>
  );
}

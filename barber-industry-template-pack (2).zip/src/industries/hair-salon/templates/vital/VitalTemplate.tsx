/**
 * HAIR SALON · VITAL — enquiry-first (salon edition).
 * A hair consultation form leads: length, texture, goals — drafted into one
 * WhatsApp message. It never claims an appointment was made; the studio
 * always confirms by reply.
 */
import { useMemo, useState } from 'react';
import {
  Check, Clock, Copy, Info, Mail, MapPin, MessageCircle, Phone, Send, ShieldCheck,
} from 'lucide-react';
import { cn } from '../../../../utils/cn';
import type { TemplateProps } from '../../../../types';
import { SmartImage } from '../../../../components/SmartImage';
import { BrandMark, SamplePill } from '../../../../components/kit';
import { formatHourRow, mailLink, telLink, waLink } from '../../../../lib/utils';

const COCOA = '#332217';
const WA = '#1faf57';
const LENGTHS = ['Short', 'Medium', 'Long'];
const TEXTURES = ['Straight', 'Wavy', 'Curly', 'Coily', 'Not sure'];

export default function VitalTemplate({ business: b, logo, photos }: TemplateProps) {
  const name = b.name || 'Your Hair Studio';
  const hasWa = b.whatsapp.replace(/[^\d]/g, '').length >= 10;
  const openDay = b.hours.find((h) => !h.closed);

  const [clientName, setClientName] = useState('');
  const [length, setLength] = useState('');
  const [texture, setTexture] = useState('');
  const [service, setService] = useState('');
  const [when, setWhen] = useState('');
  const [note, setNote] = useState('');
  const [errors, setErrors] = useState<{ name?: string; service?: string }>({});
  const [drafted, setDrafted] = useState(false);
  const [copied, setCopied] = useState(false);

  const serviceOptions = useMemo(() => b.services.map((s) => s.name).filter(Boolean), [b.services]);

  const composed = useMemo(() => {
    const lines = [
      `Hi ${name}, new hair enquiry from the website:`,
      `• Name: ${clientName || '—'}`,
      length ? `• Hair length: ${length}` : null,
      texture ? `• Texture: ${texture}` : null,
      service ? `• Interested in: ${service}` : null,
      when ? `• Preferred time: ${when}` : null,
      note ? `• Notes: ${note}` : null,
      '(This is an enquiry — please reply to confirm availability and a final quote.)',
    ].filter(Boolean);
    return lines.join('\n');
  }, [clientName, length, texture, service, when, note, name]);

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const errs: typeof errors = {};
    if (!clientName.trim()) errs.name = 'Please add your name so the studio knows who is asking.';
    if (!service) errs.service = 'Choose a service, or “Not sure yet”.';
    setErrors(errs);
    if (Object.keys(errs).length) return;
    window.open(waLink(b.whatsapp, composed), '_blank', 'noopener');
    setDrafted(true);
  }

  async function copy() {
    try {
      await navigator.clipboard.writeText(composed);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      window.prompt('Copy your enquiry:', composed);
    }
  }

  return (
    <div className="@container bg-[#f6f1ea] font-vital text-[#332217]">
      {/* ------------------------------------------------ top bar */}
      <header className="flex flex-wrap items-center justify-between gap-3 px-5 py-4 @md:px-10">
        <p className="flex items-center gap-2.5 text-[15px] font-extrabold tracking-tight">
          <BrandMark logo={logo} name={name} className="h-9 w-9 text-[10px]" />
          {name}
        </p>
        <div className="flex items-center gap-4 text-[12px] font-semibold text-[#332217]/70">
          <span className="hidden @sm:inline">{openDay ? `${openDay.label} · ${formatHourRow(openDay)}` : 'Add opening hours'}</span>
          {b.phone && (
            <a href={telLink(b.phone)} className="grid h-9 w-9 place-items-center rounded-full border border-[#332217]/25" aria-label="Phone the studio">
              <Phone className="h-4 w-4" />
            </a>
          )}
        </div>
      </header>

      {/* ------------------------------------------------ consult hero */}
      <main className="px-5 pb-14 pt-6 @md:px-10 @md:pt-10">
        <div className="grid gap-10 @lg:grid-cols-[1.02fr_1fr] @lg:items-start">
          <div>
            <p className="mb-4 inline-flex items-center gap-2 rounded-full px-3 py-1 text-[11px] font-bold uppercase tracking-[0.2em] text-white" style={{ background: COCOA }}>
              <MessageCircle className="h-3.5 w-3.5" aria-hidden /> Hair consult · {b.area || 'your area'}
            </p>
            <h1 className="text-[clamp(2rem,5.2cqw,3.7rem)] font-extrabold leading-[1.02] tracking-[-0.02em]">
              Tell us about your hair before you visit.
            </h1>
            <p className="mt-4 max-w-[48ch] text-[15px] leading-relaxed text-[#332217]/70">
              {b.tagline || 'Add your one-liner in the editor.'} Share your length, texture and goal — we reply
              during studio hours with honest advice, availability and a clear quote.
            </p>

            <div className="mt-8 max-w-md space-y-3">
              {hasWa ? (
                <a
                  href={waLink(b.whatsapp, `Hi ${name}, I'd like a quick hair consult.`)}
                  target="_blank" rel="noreferrer"
                  className="flex items-center gap-3 rounded-2xl px-5 py-4 text-white shadow-lg shadow-[#1faf57]/25 transition-transform hover:-translate-y-0.5"
                  style={{ background: WA }}
                >
                  <MessageCircle className="h-6 w-6 shrink-0" aria-hidden />
                  <span>
                    <span className="block text-[15px] font-extrabold">WhatsApp us · {b.whatsapp}</span>
                    <span className="block text-[12px] font-medium text-white/80">Fastest for colour consults and availability</span>
                  </span>
                </a>
              ) : (
                <p className="rounded-2xl border-2 border-dashed border-[#332217]/30 px-5 py-4 text-sm font-semibold text-[#332217]/60">
                  Add your WhatsApp number in the editor to switch this button live.
                </p>
              )}
              <div className="grid grid-cols-2 gap-3">
                {b.phone ? (
                  <a href={telLink(b.phone)} className="flex items-center gap-2.5 rounded-2xl border border-[#332217]/25 bg-white px-4 py-3.5 text-[13px] font-bold transition-colors hover:border-[#332217]">
                    <Phone className="h-4 w-4 shrink-0" /> {b.phone}
                  </a>
                ) : (
                  <span className="flex items-center gap-2.5 rounded-2xl border border-dashed border-[#332217]/25 px-4 py-3.5 text-[13px] font-semibold text-[#332217]/50">
                    <Phone className="h-4 w-4" /> Phone not added
                  </span>
                )}
                {b.email ? (
                  <a href={mailLink(b.email)} className="flex items-center gap-2.5 rounded-2xl border border-[#332217]/25 bg-white px-4 py-3.5 text-[13px] font-bold transition-colors hover:border-[#332217]">
                    <Mail className="h-4 w-4 shrink-0" /> Email us
                  </a>
                ) : (
                  <span className="flex items-center gap-2.5 rounded-2xl border border-dashed border-[#332217]/25 px-4 py-3.5 text-[13px] font-semibold text-[#332217]/50">
                    <Mail className="h-4 w-4" /> Email not added
                  </span>
                )}
              </div>
            </div>

            <ul className="mt-7 space-y-2.5 text-[13px] font-semibold text-[#332217]/75">
              <li className="flex items-center gap-2.5"><ShieldCheck className="h-4 w-4" style={{ color: WA }} /> An enquiry is not an appointment — we confirm by reply.</li>
              <li className="flex items-center gap-2.5"><Clock className="h-4 w-4" style={{ color: WA }} /> We answer on open days only (closed days listed below).</li>
              <li className="flex items-center gap-2.5"><Info className="h-4 w-4" style={{ color: WA }} /> A clear quote always comes before any work begins.</li>
            </ul>
          </div>

          {/* consult form */}
          <form onSubmit={submit} noValidate className="rounded-2xl border border-[#332217]/15 bg-white p-6 shadow-[0_24px_60px_-30px_rgba(51,34,23,0.4)] @md:p-8">
            <h2 className="text-xl font-extrabold tracking-tight">Hair consult form</h2>
            <p className="mt-1 text-[12.5px] text-[#332217]/60">
              Fill this in and we’ll open WhatsApp with your consult drafted. Nothing sends until you press send.
            </p>

            <label className="mt-6 block">
              <span className="mb-1.5 block text-[11px] font-extrabold uppercase tracking-[0.16em] text-[#332217]/70">Your name *</span>
              <input
                value={clientName}
                onChange={(e) => { setClientName(e.target.value); if (errors.name) setErrors({ ...errors, name: undefined }); }}
                placeholder="e.g. Naledi K."
                className={cn('w-full rounded-xl border bg-[#f6f1ea] px-4 py-3 text-sm outline-none transition-colors focus:border-[#1faf57]', errors.name ? 'border-red-400' : 'border-[#332217]/20')}
                aria-invalid={!!errors.name}
              />
              {errors.name && <span className="mt-1 block text-[12px] font-semibold text-red-600">{errors.name}</span>}
            </label>

            <fieldset className="mt-5">
              <legend className="mb-1.5 text-[11px] font-extrabold uppercase tracking-[0.16em] text-[#332217]/70">Hair length</legend>
              <div className="flex flex-wrap gap-2">
                {LENGTHS.map((l) => (
                  <Chip key={l} active={length === l} onClick={() => setLength(length === l ? '' : l)}>{l}</Chip>
                ))}
              </div>
            </fieldset>

            <fieldset className="mt-4">
              <legend className="mb-1.5 text-[11px] font-extrabold uppercase tracking-[0.16em] text-[#332217]/70">Texture</legend>
              <div className="flex flex-wrap gap-2">
                {TEXTURES.map((t) => (
                  <Chip key={t} active={texture === t} onClick={() => setTexture(texture === t ? '' : t)}>{t}</Chip>
                ))}
              </div>
            </fieldset>

            <fieldset className="mt-4">
              <legend className="mb-1.5 text-[11px] font-extrabold uppercase tracking-[0.16em] text-[#332217]/70">Interested in *</legend>
              <div className="flex flex-wrap gap-2">
                {[...serviceOptions.slice(0, 6), 'Not sure yet'].map((s) => (
                  <button
                    key={s} type="button" aria-pressed={service === s}
                    onClick={() => { setService(s); if (errors.service) setErrors({ ...errors, service: undefined }); }}
                    className={cn(
                      'rounded-full border px-3.5 py-1.5 text-[12.5px] font-bold transition-colors',
                      service === s ? 'border-transparent text-white' : 'border-[#332217]/25 text-[#332217]/75 hover:border-[#332217]',
                    )}
                    style={service === s ? { background: COCOA } : undefined}
                  >
                    {s}
                  </button>
                ))}
              </div>
              {errors.service && <span className="mt-1 block text-[12px] font-semibold text-red-600">{errors.service}</span>}
            </fieldset>

            <label className="mt-5 block">
              <span className="mb-1.5 block text-[11px] font-extrabold uppercase tracking-[0.16em] text-[#332217]/70">Preferred day &amp; time (optional)</span>
              <input value={when} onChange={(e) => setWhen(e.target.value)} placeholder="e.g. Saturday morning"
                className="w-full rounded-xl border border-[#332217]/20 bg-[#f6f1ea] px-4 py-3 text-sm outline-none transition-colors focus:border-[#1faf57]" />
            </label>

            <label className="mt-5 block">
              <span className="mb-1.5 block text-[11px] font-extrabold uppercase tracking-[0.16em] text-[#332217]/70">Your hair goal (optional)</span>
              <textarea value={note} onChange={(e) => setNote(e.target.value)} rows={3}
                placeholder="e.g. Grow out my balayage gracefully / big curl definition"
                className="w-full resize-none rounded-xl border border-[#332217]/20 bg-[#f6f1ea] px-4 py-3 text-sm outline-none transition-colors focus:border-[#1faf57]" />
            </label>

            {hasWa ? (
              <button type="submit"
                className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl px-5 py-4 text-[15px] font-extrabold text-white transition-transform hover:-translate-y-0.5"
                style={{ background: WA }}>
                <Send className="h-4 w-4" aria-hidden /> Draft my WhatsApp consult
              </button>
            ) : (
              <p className="mt-6 rounded-xl border-2 border-dashed border-[#332217]/30 px-4 py-3.5 text-center text-[13px] font-semibold text-[#332217]/60">
                The studio needs a WhatsApp number before this form can send — add one in the editor.
              </p>
            )}
            <button type="button" onClick={copy}
              className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl border border-[#332217]/20 px-5 py-3 text-[13px] font-bold text-[#332217]/75 transition-colors hover:border-[#332217]">
              {copied ? <Check className="h-4 w-4 text-[#1faf57]" /> : <Copy className="h-4 w-4" />}
              {copied ? 'Copied to clipboard' : 'Copy consult text instead'}
            </button>

            {drafted && (
              <p role="status" className="mt-4 flex items-start gap-2.5 rounded-xl bg-[#1faf57]/12 px-4 py-3 text-[12.5px] font-semibold leading-relaxed">
                <Check className="mt-0.5 h-4 w-4 shrink-0" style={{ color: WA }} />
                WhatsApp opened with your consult drafted. Press send there — the studio confirms availability
                and a final quote by reply. Nothing is booked yet.
              </p>
            )}
          </form>
        </div>

        {/* ------------------------------------------------ proof band */}
        {photos.length > 0 && (
          <div className="mt-14">
            <div className="mb-4 flex items-center gap-3">
              <p className="text-[11px] font-extrabold uppercase tracking-[0.2em] text-[#332217]/60">Inside the studio</p>
              {photos.some((p) => p.sample) && <SamplePill label="Sample photos" />}
            </div>
            <div className="grid grid-cols-2 gap-3 @md:grid-cols-4">
              {photos.slice(0, 4).map((p) => (
                <SmartImage key={p.id} src={p.src} alt={p.alt} className="aspect-[4/3] w-full rounded-xl" />
              ))}
            </div>
          </div>
        )}

        {/* ------------------------------------------------ info tiles */}
        <div className="mt-14 grid gap-4 @md:grid-cols-3">
          <div className="rounded-2xl bg-white p-6 shadow-sm">
            <p className="mb-3 flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-[0.2em] text-[#332217]/60">
              <Clock className="h-4 w-4" /> Studio hours
            </p>
            <ul className="space-y-2">
              {b.hours.map((h) => (
                <li key={h.id} className="flex justify-between gap-4 text-sm">
                  <span className="font-bold">{h.label}</span>
                  <span className="text-[#332217]/70">{h.closed ? <em>Closed</em> : formatHourRow(h)}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-2xl bg-white p-6 shadow-sm">
            <p className="mb-3 flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-[0.2em] text-[#332217]/60">
              <MapPin className="h-4 w-4" /> Where to find us
            </p>
            <p className="text-sm font-bold">{b.address || 'Add your address'}</p>
            <p className="text-sm text-[#332217]/70">{b.area || 'Your area'}</p>
            <a href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${b.address} ${b.area}`)}`}
              target="_blank" rel="noreferrer"
              className="mt-3 inline-flex items-center gap-1.5 text-[13px] font-extrabold underline decoration-[#1faf57] decoration-2 underline-offset-4">
              Get directions
            </a>
          </div>
          <div className="rounded-2xl bg-white p-6 shadow-sm">
            <p className="mb-3 flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-[0.2em] text-[#332217]/60">
              Popular services <SamplePill label="Sample prices" />
            </p>
            <ul className="space-y-2">
              {b.services.slice(0, 4).map((s) => (
                <li key={s.id} className="flex justify-between gap-4 text-sm">
                  <span className="font-bold">{s.name}</span><span className="text-[#332217]/70">{s.price}</span>
                </li>
              ))}
            </ul>
            <p className="mt-3 text-[12px] text-[#332217]/55">Full menu shared on enquiry.</p>
          </div>
        </div>
      </main>

      <footer className="flex flex-wrap items-center justify-between gap-3 border-t border-[#332217]/12 px-5 py-6 text-[11px] font-bold uppercase tracking-[0.2em] text-[#332217]/50 @md:px-10">
        <span>{name}</span>
        <span>Design: Vital · MzansiSite demo — enquiries are not booked appointments</span>
      </footer>
    </div>
  );
}

function Chip({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button type="button" aria-pressed={active} onClick={onClick}
      className={cn(
        'rounded-full border px-3.5 py-1.5 text-[12.5px] font-bold transition-colors',
        active ? 'border-transparent bg-[#332217] text-white' : 'border-[#332217]/25 text-[#332217]/75 hover:border-[#332217]',
      )}>
      {children}
    </button>
  );
}

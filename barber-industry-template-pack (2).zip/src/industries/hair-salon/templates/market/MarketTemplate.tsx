/**
 * HAIR SALON · MARKET — about-first (salon edition).
 * A warm letter from the studio owner: blush paper, cocoa ink, apricot ink-
 * stamp accents. The story leads; services and visiting details follow.
 */
import { ArrowRight, Clock, Heart, Leaf, Mail, MapPin, PenLine, Phone, Sparkles } from 'lucide-react';
import type { TemplateProps } from '../../../../types';
import { SmartImage } from '../../../../components/SmartImage';
import { BrandMark, SamplePill, WhatsAppAction } from '../../../../components/kit';
import { formatHourRow, mailLink, paragraphs, telLink } from '../../../../lib/utils';

const APRICOT = '#e0703f';

const VALUES = [
  { icon: Leaf, t: 'Healthy hair first', d: 'We protect condition before chasing colour — always.' },
  { icon: Heart, t: 'Every texture welcome', d: 'Coils, curls, waves and straight hair all get specialist care.' },
  { icon: Sparkles, t: 'Honest pricing', d: 'Quoted before we start, explained if anything changes.' },
];

export default function MarketTemplate({ business: b, logo, photos, onEditRequest }: TemplateProps) {
  const name = b.name || 'Your Hair Studio';
  const paras = paragraphs(b.description);
  const pics = photos.slice(0, 3);

  return (
    <div className="@container bg-[#faf1ea] font-market-sans text-[#3b2417]">
      {/* ------------------------------------------------ masthead */}
      <header className="border-b border-[#3b2417]/12 px-5 py-6 @md:px-10">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <BrandMark logo={logo} name={name} className="h-11 w-11 text-xs" />
            <div className="leading-tight">
              <p className="font-market text-xl font-semibold">{name}</p>
              <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-[#3b2417]/60">{b.area || 'Your area'}</p>
            </div>
          </div>
          <WhatsAppAction
            whatsapp={b.whatsapp}
            message={`Hi ${name}, I'd love to talk about my hair.`}
            className="rounded-full bg-[#3b2417] px-5 py-2.5 text-sm font-semibold text-[#faf1ea] transition-transform hover:-translate-y-0.5"
            label="Say hello"
          />
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-5 @md:px-10">
        {/* ------------------------------------------------ the letter */}
        <section className="border-b border-dashed border-[#3b2417]/25 py-12 @md:py-16">
          <p className="mb-5 inline-flex -rotate-2 items-center gap-2 rounded-sm px-3 py-1 text-[11px] font-bold uppercase tracking-[0.22em] text-white shadow-sm" style={{ background: APRICOT }}>
            <PenLine className="h-3.5 w-3.5" aria-hidden /> A letter from the studio
          </p>
          <h1 className="font-market text-[clamp(2rem,5.4cqw,4rem)] font-semibold leading-[1.05]">
            {b.tagline || 'Every salon has a story. This one starts with yours.'}
          </h1>

          {paras.length === 0 ? (
            <button type="button" onClick={() => onEditRequest?.('business')}
              className="mt-8 w-full rounded-xl border-2 border-dashed border-[#3b2417]/30 bg-white/60 px-6 py-12 text-left">
              <p className="flex items-center gap-2 font-market text-xl font-semibold" style={{ color: APRICOT }}>
                <PenLine className="h-5 w-5" /> Write your letter here
              </p>
              <p className="mt-2 max-w-[56ch] text-sm leading-relaxed text-[#3b2417]/70">
                How did the studio begin? What do regulars love about it? What should a nervous first-timer know?
                Add it in the editor — this space is reserved for the real thing.
              </p>
            </button>
          ) : (
            <div className="mx-auto mt-8 max-w-3xl rounded-xl border border-[#3b2417]/15 bg-white/70 p-6 shadow-[0_20px_50px_-30px_rgba(59,36,23,0.35)] @md:p-10">
              <p className="font-market text-xl font-semibold italic">Dear {b.area || 'friend'},</p>
              {paras.map((p, i) => (
                <p key={i} className="mt-4 font-market text-[1.05rem] leading-relaxed text-[#3b2417]/85">{p}</p>
              ))}
              <p className="mt-6 font-market text-lg font-semibold italic" style={{ color: APRICOT }}>— {name}</p>
              <SamplePill label="Sample letter — edit in 'Business'" className="mt-4" />
            </div>
          )}
        </section>

        {/* ------------------------------------------------ what we believe */}
        <section className="border-b border-dashed border-[#3b2417]/25 py-12 @md:py-14">
          <div className="mb-8 flex flex-wrap items-center gap-3">
            <h2 className="font-market text-[clamp(1.5rem,3.4cqw,2.3rem)] font-semibold">What we believe</h2>
            <SamplePill label="Sample values" />
          </div>
          <div className="grid gap-5 @md:grid-cols-3">
            {VALUES.map((v) => (
              <div key={v.t} className="rounded-2xl border border-[#3b2417]/12 bg-white/70 p-6">
                <span className="grid h-11 w-11 place-items-center rounded-full bg-[#faf1ea]" style={{ color: APRICOT }}>
                  <v.icon className="h-5 w-5" aria-hidden />
                </span>
                <h3 className="mt-4 font-market text-lg font-semibold">{v.t}</h3>
                <p className="mt-1.5 text-[13.5px] leading-relaxed text-[#3b2417]/70">{v.d}</p>
              </div>
            ))}
          </div>
        </section>

        {/* ------------------------------------------------ polaroid row */}
        {pics.length > 0 && (
          <section className="border-b border-dashed border-[#3b2417]/25 py-12">
            <div className="mb-6 flex items-center justify-between">
              <h2 className="font-market text-[clamp(1.5rem,3.4cqw,2.3rem)] font-semibold">Around the studio</h2>
              {photos.some((p) => p.sample) && <SamplePill label="Sample photos" />}
            </div>
            <div className="grid gap-5 @sm:grid-cols-3">
              {pics.map((p, i) => (
                <figure key={p.id} className="rounded-lg border border-[#3b2417]/15 bg-white p-2.5 pb-3 shadow-sm transition-transform hover:rotate-0"
                  style={{ transform: `rotate(${i % 2 === 0 ? -1.2 : 1.1}deg)` }}>
                  <SmartImage src={p.src} alt={p.alt} className="aspect-[4/3] w-full rounded-md" />
                  <figcaption className="mt-2.5 flex items-center justify-between px-1 font-market text-[13px] italic text-[#3b2417]/70">
                    <span className="truncate">{p.alt}</span>
                    {p.sample && <SamplePill label="Sample" />}
                  </figcaption>
                </figure>
              ))}
            </div>
          </section>
        )}

        {/* ------------------------------------------------ the menu */}
        <section className="border-b border-dashed border-[#3b2417]/25 py-12 @md:py-14">
          <div className="mb-8 flex flex-wrap items-center gap-3">
            <h2 className="font-market text-[clamp(1.5rem,3.4cqw,2.3rem)] font-semibold">What keeps our chairs busy</h2>
            <SamplePill label="Sample prices" />
          </div>
          <ul className="overflow-hidden rounded-xl border border-[#3b2417]/15 bg-white/70">
            {b.services.map((s, i) => (
              <li key={s.id} className="flex flex-wrap items-baseline gap-x-4 gap-y-1 border-b border-dashed border-[#3b2417]/15 px-5 py-4 last:border-0">
                <span className="rounded-full bg-[#faf1ea] px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-[0.14em]" style={{ color: APRICOT }}>{s.category}</span>
                <span className="min-w-0 flex-1">
                  <span className="font-market text-lg font-semibold">{s.name}</span>
                  {s.description && <span className="block text-[13px] text-[#3b2417]/65">{s.description}</span>}
                </span>
                <span className="font-market text-lg font-semibold">{s.price}</span>
                {i === 0 && <span className="sr-only">End of first service</span>}
              </li>
            ))}
            {b.services.length === 0 && (
              <li className="px-5 py-10 text-center text-sm text-[#3b2417]/60">No services yet — add your menu in the editor.</li>
            )}
          </ul>
        </section>

        {/* ------------------------------------------------ visit */}
        <section className="grid gap-5 py-12 @md:py-14 @md:grid-cols-2">
          {/* illustrated map card */}
          <div className="relative overflow-hidden rounded-xl border border-[#3b2417]/20 bg-[#f4e7da] p-5">
            <svg aria-hidden className="absolute inset-0 h-full w-full text-[#3b2417]/10" preserveAspectRatio="none" viewBox="0 0 100 100">
              <path d="M0 25 H100 M0 60 H100 M0 88 H100 M22 0 V100 M58 0 V100 M84 0 V100" stroke="currentColor" strokeWidth="0.6" fill="none" />
              <path d="M22 60 Q40 45 58 58 T100 52" stroke="currentColor" strokeWidth="1.2" fill="none" />
            </svg>
            <div className="relative">
              <p className="flex items-center gap-2 font-market text-xl font-semibold">
                <MapPin className="h-5 w-5" style={{ color: APRICOT }} />{b.address || 'Add your address'}
              </p>
              <p className="mt-1 text-sm font-semibold text-[#3b2417]/70">{b.area || 'Your area'}</p>
              <a href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${b.address} ${b.area}`)}`}
                target="_blank" rel="noreferrer"
                className="mt-4 inline-flex items-center gap-1.5 rounded-lg bg-[#3b2417] px-4 py-2 text-sm font-semibold text-[#faf1ea]">
                Open in Maps <ArrowRight className="h-3.5 w-3.5" />
              </a>
            </div>
          </div>
          {/* hours + contact */}
          <div className="rounded-xl border border-[#3b2417]/20 bg-white/70 p-5">
            <p className="mb-3 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.2em] text-[#3b2417]/60">
              <Clock className="h-3.5 w-3.5" /> Studio hours
            </p>
            <ul className="space-y-2.5">
              {b.hours.map((h) => (
                <li key={h.id} className="flex justify-between gap-4 text-sm">
                  <span className="font-semibold">{h.label}</span>
                  <span>{h.closed ? <em className="text-[#3b2417]/55">Closed</em> : formatHourRow(h)}</span>
                </li>
              ))}
            </ul>
            <div className="mt-5 space-y-2 border-t border-dashed border-[#3b2417]/20 pt-4 text-sm">
              {b.phone && <a href={telLink(b.phone)} className="flex items-center gap-2 font-semibold hover:underline"><Phone className="h-3.5 w-3.5" /> {b.phone}</a>}
              {b.email && <a href={mailLink(b.email)} className="flex items-center gap-2 font-semibold hover:underline"><Mail className="h-3.5 w-3.5" /> {b.email}</a>}
            </div>
          </div>
        </section>

        {/* ------------------------------------------------ closing ribbon */}
        <section className="mb-14 rounded-2xl bg-[#3b2417] px-6 py-10 text-center text-[#faf1ea] @md:px-12">
          <p className="font-market text-[clamp(1.4rem,3.4cqw,2.2rem)] font-semibold italic leading-snug">
            “{b.tagline || 'Leave lighter than you arrived.'}”
          </p>
          <WhatsAppAction
            whatsapp={b.whatsapp}
            message={`Hi ${name}, I'd love to talk about my hair.`}
            className="mt-6 rounded-lg bg-[#faf1ea] px-7 py-3 text-sm font-semibold text-[#3b2417] transition-transform hover:-translate-y-0.5"
            label="Start with a message"
          />
          <p className="mt-4 text-[11px] uppercase tracking-[0.2em] text-[#faf1ea]/60">Answered during studio hours — closed days are resting days</p>
        </section>
      </main>

      <footer className="border-t border-[#3b2417]/12 px-5 py-6 text-center text-[11px] font-semibold uppercase tracking-[0.2em] text-[#3b2417]/50">
        {name} · Design: Market · MzansiSite demo — story and prices are samples until edited
      </footer>
    </div>
  );
}

/**
 * SAMPLE CONTENT — hair salon industry.
 *
 * Demonstration data only, labelled "sample" wherever money, trust or contact
 * details are implied. No reviews, ratings, awards or credentials are
 * invented: `credentials` ships empty by design.
 *
 * IMAGERY RULES (Islamic-values compliant): interiors, styling tools, towels
 * and product shelves only. No people, faces, bodies or hands appear in any
 * bundled sample image. Two images are generated locally; the remainder are
 * curated people-free stock photographs loaded from a CDN at runtime.
 */
import type { BusinessData, PhotoItem, ServiceItem } from '../../../types';
import { uid } from '../../../lib/utils';

import imgHero from '../assets/hero-interior.jpg';
import imgTools from '../assets/tools-flatlay.jpg';

const px = (id: number) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200`;

export const SAMPLE_PHOTOS: PhotoItem[] = [
  { id: uid(), src: imgHero, alt: 'Styling chairs and brass-framed mirrors in a sunlit salon interior', sample: true },
  { id: uid(), src: px(7750124), alt: 'Elegant salon interior with round mirrors and soft lighting', sample: true },
  { id: uid(), src: px(7750108), alt: 'Sleek styling stations with illuminated vanity mirrors', sample: true },
  { id: uid(), src: imgTools, alt: 'Salon scissors, brushes and colour tools arranged on sage linen', sample: true },
  { id: uid(), src: px(7195807), alt: 'Backwash stations and product display in a bright salon', sample: true },
  { id: uid(), src: px(3993121), alt: 'Salon shelves stocked with hair care products', sample: true },
  { id: uid(), src: px(15852132), alt: 'Rolled cotton towels resting on a wooden shelf', sample: true },
  { id: uid(), src: px(7750107), alt: 'Waiting lounge with leather seating and marble floors', sample: true },
];

const svc = (category: string, name: string, price: string, description: string): ServiceItem => ({
  id: uid(), category, name, price, description,
});

export const SAMPLE_SERVICES: ServiceItem[] = [
  svc('Cut & Style', 'Wash, Cut & Blow', 'R650', 'Consultation, precision cut, cleanse and blow-wave finish.'),
  svc('Cut & Style', 'Dry Restyle & Finish', 'R480', 'Reshape or restyle finished with a soft blow-dry.'),
  svc('Cut & Style', 'Gents’ Clipper Cut', 'R220', 'Clean clipper work with a tidy neckline.'),
  svc('Cut & Style', 'Fringe & Tidy', 'R120', 'Between-cuts fringe trim and neckline tidy.'),
  svc('Colour', 'Balayage & Toner', 'R1 450', 'Hand-painted lightness finished with a glossing toner.'),
  svc('Colour', 'Full Head Colour', 'R950', 'Single-process colour from roots to ends.'),
  svc('Colour', 'Root Touch-Up', 'R650', 'Regrowth colour matched to your existing shade.'),
  svc('Colour', 'Gloss & Tone', 'R380', 'Shine-boosting tonal refresh between colour appointments.'),
  svc('Treatments', 'Bond-Repair Treatment', 'R550', 'Deep bond-building care for coloured or lightened hair.'),
  svc('Treatments', 'Keratin Smoothing', 'R1 200', 'Frizz-reducing smoothing treatment done unhurried.'),
  svc('Treatments', 'Steam Hydration Mask', 'R320', 'Steam-infused mask for dry or stressed hair.'),
  svc('Texture', 'Silk Press', 'R420', 'Smooth, glossy press with heat protection throughout.'),
  svc('Texture', 'Braid-Out / Twist-Out', 'R380', 'Set, dried and separated for defined texture.'),
  svc('Texture', 'Occasion Upstyle', 'R550', 'Pinned, braided or sleek styling for events.'),
  svc('Texture', 'Wash & Blow-Wave', 'R260', 'Cleanse, condition and a bouncy blow-wave.'),
];

export const SAMPLE_BUSINESS: BusinessData = {
  name: 'Marula Gold Hair Studio',
  tagline: 'Colour, cuts and honest care — healthy hair first.',
  description:
    'Marula Gold is a demonstration hair studio profile used to show what these designs look like with real content.\nReplace this story with your own: how the studio started, the textures you love working with, and how you look after first-time clients.',
  whatsapp: '27835550382',
  phone: '011 555 0382',
  email: 'hello@marulagold.co.za',
  address: '12 4th Avenue',
  area: 'Parkhurst, Johannesburg',
  hours: [
    { id: uid(), label: 'Monday', open: '', close: '', closed: true },
    { id: uid(), label: 'Tuesday', open: '08:30', close: '17:30', closed: false },
    { id: uid(), label: 'Wednesday', open: '08:30', close: '17:30', closed: false },
    { id: uid(), label: 'Thursday', open: '08:30', close: '17:30', closed: false },
    { id: uid(), label: 'Friday', open: '08:30', close: '17:30', closed: false },
    { id: uid(), label: 'Saturday', open: '08:00', close: '15:00', closed: false },
    { id: uid(), label: 'Sunday', open: '', close: '', closed: true },
  ],
  services: SAMPLE_SERVICES,
  credentials: [], // honest by design — see file header
};

/** Deep copy so edits never mutate the sample constants. */
export function freshSampleContent(): BusinessData {
  return JSON.parse(JSON.stringify(SAMPLE_BUSINESS)) as BusinessData;
}

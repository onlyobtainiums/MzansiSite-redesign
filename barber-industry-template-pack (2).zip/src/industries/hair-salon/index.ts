/**
 * Hair Salon industry module.
 *
 * Same contract, six design directions and technical standards as the Barber
 * pack — entirely different designs, sample data and imagery. Imagery follows
 * the strict no-people rule (interiors, tools, towels, products only).
 */
import type { IndustryModule } from '../types';
import { freshSampleContent, SAMPLE_PHOTOS } from './data/hairSalonPack';
import { TEMPLATES } from './templates/registry';

export const hairSalonIndustry: IndustryModule = {
  id: 'hair-salon',
  label: 'Hair Salon',
  packKicker: 'Hair Salon Template Pack · 6 designs',
  chooserHeadline: 'Six ways to put your hair salon online.',
  chooserIntro:
    'Six genuinely different designs, each a real working website. Pick one, add your services, hours and photos in a free preview, and only pay when you’re ready to publish. Switching designs keeps everything you’ve typed.',
  imageryNote: 'Imagery rule (Islamic-values compliant): interiors, tools, towels and product shelves only — no people, faces, bodies or hands anywhere, including demo uploads.',
  draftKey: 'mzansisite.draft.hair-salon.v1',
  sampleBusiness: freshSampleContent,
  samplePhotos: SAMPLE_PHOTOS,
  templates: TEMPLATES,
};

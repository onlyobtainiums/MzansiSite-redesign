import { useState } from 'react';
import { StudioProvider, useStudio } from './state/StudioContext';
import DesignChooser from './chooser/DesignChooser';
import PreviewStudio from './studio/PreviewStudio';
import { DEFAULT_INDUSTRY, industryById } from './industries';

function Shell() {
  const { view } = useStudio();
  return (
    <div key={view} className="mz-fade-in">
      {view === 'chooser' ? <DesignChooser /> : <PreviewStudio />}
    </div>
  );
}

export default function App() {
  const [industryId, setIndustryId] = useState<string>(DEFAULT_INDUSTRY);
  const industry = industryById(industryId);
  return (
    <StudioProvider key={industry.id} industry={industry} onSwitchIndustry={setIndustryId}>
      <Shell />
    </StudioProvider>
  );
}

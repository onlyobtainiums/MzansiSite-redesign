/**
 * Studio state — single source of truth for the whole prototype.
 *
 * CONTENT PRESERVATION
 * • Business details, services, hours, credentials, logo, photos and the
 *   selected design are context-owned: switching templates or a change in
 *   subscription status never resets them.
 * • A TEXT-ONLY draft (business fields + selected design) is auto-kept in
 *   sessionStorage — this browser tab only, clearly labelled. Photos and the
 *   logo are data-heavy upload binaries and are intentionally NOT persisted
 *   by the static prototype (browser storage quotas would discard them
 *   silently, which our honesty rules forbid). The editor says so plainly.
 *
 * ENTITLEMENTS
 * • Photo capacity comes exclusively from `deriveEntitlement(session)` in
 *   src/config/entitlements.ts. The session must be server-verified by the
 *   platform; opening the editor or starting checkout changes nothing.
 */
import React, {
  createContext, useCallback, useContext, useEffect, useMemo, useRef, useState,
} from 'react';
import type {
  BusinessData, EditorTab, HourRow, PhotoItem, ServiceItem, StudioContent, TemplateId,
} from '../types';
import type { IndustryModule } from '../industries/types';
import { deriveEntitlement, type Entitlement, type VerifiedSubscriptionSession } from '../config/entitlements';
import { uid } from '../lib/utils';

export type View = 'chooser' | 'studio';
export type Device = 'mobile' | 'desktop';

interface StudioState extends StudioContent {
  view: View;
  device: Device;
  editorTab: EditorTab;
  activeTemplate: TemplateId;
  dirty: boolean;
  rotationPaused: boolean;
  /** the active industry module (barber, hair-salon, …) */
  industry: IndustryModule;
  /** switch the whole studio to another industry pack */
  switchIndustry: (id: string) => void;
  /** Free vs paid capability — the ONLY source of the photo limit. */
  entitlement: Entitlement;
  /** null in this prototype; the platform sets it after server-side verification */
  session: VerifiedSubscriptionSession | null;
  draftRestored: boolean;

  openStudio: (template: TemplateId) => void;
  backToChooser: () => void;
  setActiveTemplate: (id: TemplateId) => void;
  setDevice: (d: Device) => void;
  setEditorTab: (t: EditorTab) => void;
  setRotationPaused: (p: boolean) => void;
  openEditorTab: (tab: EditorTab) => void;

  updateBusiness: (patch: Partial<BusinessData>) => void;
  updateService: (id: string, patch: Partial<ServiceItem>) => void;
  addService: () => void;
  removeService: (id: string) => void;
  updateHour: (id: string, patch: Partial<HourRow>) => void;
  addHourRow: () => void;
  removeHourRow: (id: string) => void;
  setCredential: (index: number, value: string) => void;
  addCredential: () => void;
  removeCredential: (index: number) => void;

  setLogo: (dataUrl: string | null) => void;
  addPhotos: (items: Omit<PhotoItem, 'id'>[]) => void;
  removePhoto: (id: string) => void;
  replacePhoto: (id: string, src: string) => void;
  /** reorder: -1 moves earlier, +1 later */
  movePhoto: (id: string, dir: -1 | 1) => void;

  resetAll: () => void;
  clearDraft: () => void;
}

const StudioCtx = createContext<StudioState | null>(null);

interface DraftShape { business: BusinessData; activeTemplate: TemplateId }

function readDraft(key: string, industry: IndustryModule): DraftShape | null {
  try {
    const raw = sessionStorage.getItem(key);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as DraftShape;
    if (!parsed?.business?.services || !parsed?.business?.hours) return null;
    const validTemplate = industry.templates.some((t) => t.id === parsed.activeTemplate)
      ? parsed.activeTemplate
      : 'velvet';
    return { business: parsed.business, activeTemplate: validTemplate };
  } catch {
    return null;
  }
}

export function StudioProvider({
  children,
  industry,
  onSwitchIndustry,
}: {
  children: React.ReactNode;
  industry: IndustryModule;
  onSwitchIndustry?: (id: string) => void;
}) {
  const DRAFT_KEY = industry.draftKey;
  // No session can ever exist in the static prototype — the platform mints it.
  const [session] = useState<VerifiedSubscriptionSession | null>(null);
  const entitlement = useMemo(() => deriveEntitlement(session), [session]);

  const [view, setView] = useState<View>('chooser');
  const [device, setDevice] = useState<Device>('desktop');
  const [editorTab, setEditorTab] = useState<EditorTab>('business');
  const [rotationPaused, setRotationPaused] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [draftRestored, setDraftRestored] = useState(false);

  const [activeTemplate, setActiveTemplate] = useState<TemplateId>(() => readDraft(DRAFT_KEY, industry)?.activeTemplate ?? 'velvet');
  const [content, setContent] = useState<StudioContent>(() => {
    const draft = readDraft(DRAFT_KEY, industry);
    if (draft) {
      return { business: draft.business, logo: null, photos: industry.samplePhotos };
    }
    return { business: industry.sampleBusiness(), logo: null, photos: industry.samplePhotos };
  });
  const didRestore = useRef(false);
  useEffect(() => {
    if (!didRestore.current && readDraft(DRAFT_KEY, industry)) {
      didRestore.current = true;
      setDraftRestored(true);
    }
  }, [DRAFT_KEY, industry]);

  // Auto-keep a TEXT-ONLY draft in this tab. Photos/logo deliberately excluded.
  useEffect(() => {
    try {
      sessionStorage.setItem(
        DRAFT_KEY,
        JSON.stringify({ business: content.business, activeTemplate } satisfies DraftShape),
      );
    } catch {
      /* storage full or unavailable: the prototype never pretends anything was saved */
    }
  }, [content.business, activeTemplate]);

  const touch = useCallback((mut: (c: StudioContent) => StudioContent) => {
    setContent((c) => mut(c));
    setDirty(true);
  }, []);

  const openStudio = useCallback((template: TemplateId) => {
    setActiveTemplate(template);
    setView('studio');
    setRotationPaused(true);
    requestAnimationFrame(() => window.scrollTo({ top: 0 }));
  }, []);

  const backToChooser = useCallback(() => {
    setView('chooser');
    requestAnimationFrame(() => window.scrollTo({ top: 0 }));
  }, []);

  const openEditorTab = useCallback((tab: EditorTab) => setEditorTab(tab), []);
  const clearDraft = useCallback(() => {
    try { sessionStorage.removeItem(DRAFT_KEY); } catch { /* noop */ }
    setDraftRestored(false);
  }, []);

  const api: StudioState = useMemo(
    () => ({
      view, device, editorTab, activeTemplate, dirty, rotationPaused,
      industry,
      switchIndustry: (id: string) => {
        onSwitchIndustry?.(id);
        requestAnimationFrame(() => window.scrollTo({ top: 0 }));
      },
      entitlement, session, draftRestored,
      business: content.business, logo: content.logo, photos: content.photos,

      openStudio, backToChooser,
      setActiveTemplate, setDevice, setEditorTab, setRotationPaused, openEditorTab, clearDraft,

      updateBusiness: (patch) => touch((c) => ({ ...c, business: { ...c.business, ...patch } })),

      updateService: (id, patch) =>
        touch((c) => ({
          ...c,
          business: {
            ...c.business,
            services: c.business.services.map((s) => (s.id === id ? { ...s, ...patch } : s)),
          },
        })),
      addService: () =>
        touch((c) => ({
          ...c,
          business: {
            ...c.business,
            services: [...c.business.services, { id: uid(), category: 'Cuts', name: '', price: '', description: '' }],
          },
        })),
      removeService: (id) =>
        touch((c) => ({
          ...c,
          business: { ...c.business, services: c.business.services.filter((s) => s.id !== id) },
        })),

      updateHour: (id, patch) =>
        touch((c) => ({
          ...c,
          business: {
            ...c.business,
            hours: c.business.hours.map((h) => (h.id === id ? { ...h, ...patch } : h)),
          },
        })),
      addHourRow: () =>
        touch((c) => ({
          ...c,
          business: {
            ...c.business,
            hours: [...c.business.hours, { id: uid(), label: '', open: '09:00', close: '17:00', closed: false }],
          },
        })),
      removeHourRow: (id) =>
        touch((c) => ({
          ...c,
          business: { ...c.business, hours: c.business.hours.filter((h) => h.id !== id) },
        })),

      setCredential: (index, value) =>
        touch((c) => ({
          ...c,
          business: {
            ...c.business,
            credentials: c.business.credentials.map((v, i) => (i === index ? value : v)),
          },
        })),
      addCredential: () =>
        touch((c) => ({
          ...c,
          business: { ...c.business, credentials: [...c.business.credentials, ''] },
        })),
      removeCredential: (index) =>
        touch((c) => ({
          ...c,
          business: { ...c.business, credentials: c.business.credentials.filter((_, i) => i !== index) },
        })),

      setLogo: (dataUrl) => touch((c) => ({ ...c, logo: dataUrl })),

      // Capacity enforced here (context action) AND surfaced in the uploader;
      // in production the platform API re-checks with assertPhotoCapacity().
      // Only the user's own uploads count — sample placeholders are free.
      addPhotos: (items) =>
        touch((c) => {
          const own = c.photos.filter((p) => !p.sample).length;
          const room = Math.max(0, entitlement.photoLimit - own);
          const accepted = items.slice(0, room).map((it) => ({ ...it, id: uid() }));
          return { ...c, photos: [...c.photos, ...accepted] };
        }),
      removePhoto: (id) => touch((c) => ({ ...c, photos: c.photos.filter((p) => p.id !== id) })),
      replacePhoto: (id, src) =>
        touch((c) => ({
          ...c,
          photos: c.photos.map((p) =>
            p.id === id ? { ...p, src, sample: false, alt: `${c.business.name || 'Shop'} photo` } : p,
          ),
        })),
      movePhoto: (id, dir) =>
        touch((c) => {
          const idx = c.photos.findIndex((p) => p.id === id);
          const next = idx + dir;
          if (idx < 0 || next < 0 || next >= c.photos.length) return c;
          const photos = [...c.photos];
          [photos[idx], photos[next]] = [photos[next], photos[idx]];
          return { ...c, photos };
        }),

      resetAll: () => {
        setContent({ business: industry.sampleBusiness(), logo: null, photos: industry.samplePhotos });
        setDirty(false);
        clearDraft();
      },
    }),
    [view, device, editorTab, activeTemplate, dirty, rotationPaused, industry, onSwitchIndustry, entitlement, session, draftRestored, content, openStudio, backToChooser, openEditorTab, clearDraft, touch],
  );

  return <StudioCtx.Provider value={api}>{children}</StudioCtx.Provider>;
}

export function useStudio(): StudioState {
  const ctx = useContext(StudioCtx);
  if (!ctx) throw new Error('useStudio must be used inside StudioProvider');
  return ctx;
}

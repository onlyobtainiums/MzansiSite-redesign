import type { IndustryModule } from './types';
import { barberIndustry } from './barber';
import { hairSalonIndustry } from './hair-salon';
import { spaIndustry } from './spa';

export const INDUSTRIES: IndustryModule[] = [barberIndustry, hairSalonIndustry, spaIndustry];
export const DEFAULT_INDUSTRY = 'spa';

export const industryById = (id: string): IndustryModule =>
  INDUSTRIES.find((i) => i.id === id) ?? INDUSTRIES[0];

/**
 * SAMPLE CONTENT — spa & massage therapy industry.
 *
 * Demonstration data only, labelled "sample" wherever money, trust or contact
 * details are implied. No reviews, ratings, awards, therapist qualifications
 * or health outcomes are invented: `credentials` ships empty by design and no
 * template claims any medical or therapeutic result.
 *
 * IMAGERY RULES (Islamic-values compliant): treatment rooms, towels, oils,
 * candles, stones and product still lifes only. No people, faces, bodies,
 * hands or immodest imagery appears in any bundled sample image. All sample
 * photography is curated people-free stock loaded from a CDN at runtime.
 *
 * NO AUDIO: this pack contains no music, no autoplay sound, no media players.
 */
import type { BusinessData, PhotoItem, ServiceItem } from '../../../types';
import { uid } from '../../../lib/utils';

const px = (id: number, portrait = false) =>
  portrait
    ? `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=900&w=640`
    : `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200`;

export const SAMPLE_PHOTOS: PhotoItem[] = [
  { id: uid(), src: px(6628475), alt: 'Freshly dressed massage table with white linen and headrest', sample: true },
  { id: uid(), src: px(10521232), alt: 'Calm treatment room with a made-up therapy bed and soft lighting', sample: true },
  { id: uid(), src: px(7195804), alt: 'Light treatment couch beside a sunlit window', sample: true },
  { id: uid(), src: px(6694141), alt: 'Amber essential-oil bottles arranged on a wooden tray', sample: true },
  { id: uid(), src: px(1926811), alt: 'Lit candles with folded towels and fresh flowers', sample: true },
  { id: uid(), src: px(6186740), alt: 'Single lit candle in a ceramic holder beside plush towels', sample: true },
  { id: uid(), src: px(15528977, true), alt: 'Marble hammam interior with towels and candlelight', sample: true },
  { id: uid(), src: px(6628486, true), alt: 'Rolled towels and a reed diffuser by a quiet window', sample: true },
];

const svc = (
  category: string, name: string, duration: string, price: string, description: string,
): ServiceItem => ({ id: uid(), category, name, duration, price, description });

export const SAMPLE_SERVICES: ServiceItem[] = [
  svc('Massage', 'Full Body Relaxation', '60 min', 'R690', 'Slow, flowing pressure over the whole body with warm oil.'),
  svc('Massage', 'Full Body Relaxation', '90 min', 'R940', 'The unhurried version — extra time on back, neck and feet.'),
  svc('Massage', 'Deep Tissue Focus', '60 min', 'R780', 'Firmer, targeted work on tight shoulders, back or legs.'),
  svc('Massage', 'Back, Neck & Shoulders', '30 min', 'R420', 'A focused reset for desk tension, no full undress needed.'),
  svc('Massage', 'Hot Stone Therapy', '75 min', 'R890', 'Warm basalt stones with slow massage to ease stiffness.'),
  svc('Massage', 'Aromatherapy Massage', '60 min', 'R740', 'Light-to-medium pressure with a blend chosen at consultation.'),
  svc('Body', 'Salt & Oil Body Polish', '45 min', 'R560', 'Gentle exfoliation finished with a nourishing body oil.'),
  svc('Body', 'Back Cleanse & Treat', '45 min', 'R590', 'Cleanse, exfoliation and mask for hard-to-reach skin.'),
  svc('Body', 'Warm Cocoon Wrap', '60 min', 'R680', 'A warming wrap with quiet rest time included.'),
  svc('Face', 'Classic Calm Facial', '60 min', 'R690', 'Cleanse, exfoliate, mask and hydrate for sensitive skin.'),
  svc('Face', 'Express Glow Facial', '30 min', 'R420', 'A quick refresh when time is short.'),
  svc('Face', 'Deep Hydration Facial', '75 min', 'R850', 'Layered hydration with extended mask and massage time.'),
  svc('Hands & Feet', 'Foot Ritual & Massage', '45 min', 'R480', 'Soak, scrub and pressure-point foot massage.'),
  svc('Hands & Feet', 'Hand Repair Treatment', '30 min', 'R320', 'Exfoliation, warm mask and a short massage.'),
  svc('Packages', 'Half-Day Quiet Package', '150 min', 'R1 850', 'Massage, facial and foot ritual with rest time between.'),
  svc('Packages', 'Couples Room (per person)', '60 min', 'R760', 'Two therapists in our double room — booked as one enquiry.'),
];

export const SAMPLE_BUSINESS: BusinessData = {
  name: 'Still Point Wellness',
  tagline: 'A quiet hour that belongs to you.',
  description:
    'Still Point is a demonstration spa profile used to show what these designs look like with real content.\nReplace this with your own: how your rooms feel, how you tailor pressure and products, and what a first visit looks like from arrival to the last cup of tea.',
  whatsapp: '27820095514',
  phone: '031 555 0095',
  email: 'hello@stillpoint.co.za',
  address: '8 Clifton Lane',
  area: 'Morningside, Durban',
  hours: [
    { id: uid(), label: 'Monday', open: '', close: '', closed: true },
    { id: uid(), label: 'Tuesday', open: '09:00', close: '18:00', closed: false },
    { id: uid(), label: 'Wednesday', open: '09:00', close: '18:00', closed: false },
    { id: uid(), label: 'Thursday', open: '09:00', close: '20:00', closed: false },
    { id: uid(), label: 'Friday', open: '09:00', close: '20:00', closed: false },
    { id: uid(), label: 'Saturday', open: '08:30', close: '16:00', closed: false },
    { id: uid(), label: 'Sunday', open: '10:00', close: '14:00', closed: false },
  ],
  services: SAMPLE_SERVICES,
  credentials: [], // honest by design — see file header
};

/** Deep copy so edits never mutate the sample constants. */
export function freshSampleContent(): BusinessData {
  return JSON.parse(JSON.stringify(SAMPLE_BUSINESS)) as BusinessData;
}

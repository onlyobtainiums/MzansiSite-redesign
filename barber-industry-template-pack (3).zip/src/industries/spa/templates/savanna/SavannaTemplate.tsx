/**
 * SPA · SAVANNA — trust-first (spa edition).
 * Leads with practical care information: what a visit involves, comfort and
 * privacy practices, a health-honesty note, hours and directions.
 * Credentials appear only when genuinely supplied — never invented, and no
 * medical or therapeutic outcome is ever claimed.
 */
import {
  BadgeCheck, Clock, Droplets, Mail, MapPin, MessageCircle, Navigation,
  Phone, ShieldCheck, Sparkles, Timer, Waves,
} from 'lucide-react';
import type { TemplateProps } from '../../../../types';
import { SmartImage } from '../../../../components/SmartImage';
import { BrandMark, SamplePill, WhatsAppAction } from '../../../../components/kit';
import { formatHourRow, mailLink, telLink } from '../../../../lib/utils';

const MOSS = '#5a7360';
const BARK = '#2f3a33';

const VISIT = [
  { n: '01', t: 'Arrive & settle', d: 'Come ten minutes early for a quiet start, a glass of water and a short form.' },
  { n: '02', t: 'Consultation', d: 'We ask about pressure, sensitivities, allergies and any areas to avoid.' },
  { n: '03', t: 'Your treatment', d: 'Draped in towels throughout. Tell us any time if pressure or temperature needs changing.' },
  { n: '04', t: 'Rest after', d: 'Take your time getting up. Rest and water are part of the appointment.' },
];

const CARE = [
  { icon: ShieldCheck, text: 'Fresh linen and sanitised equipment for every guest' },
  { icon: Waves, text: 'Private treatment rooms with a door that stays closed' },
  { icon: Droplets, text: 'Products patch-tested on request; ingredient lists available' },
  { icon: Sparkles, text: 'Quiet rooms — no music is played unless you ask for it' },
  { icon: Timer, text: 'Stated durations include consultation and dressing time' },
];

export default function SavannaTemplate({ business: b, logo, photos, onEditRequest }: TemplateProps) {
  const name = b.name || 'Your Spa';
  const feature = photos[1] ?? photos[0];

  return (
    <div className="@container bg-[#f0f2ec] font-savanna-sans text-[#2f3a33]">
      {/* ------------------------------------------------ header */}
      <header className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-5 pt-7 @md:px-8">
        <div className="flex items-center gap-3">
          <BrandMark logo={logo} name={name} className="h-11 w-11 text-xs" />
          <div className="leading-tight">
            <p className="font-savanna text-lg font-semibold">{name}</p>
            <p className="text-[11px] font-bold uppercase tracking-[0.22em]" style={{ color: MOSS }}>{b.area || 'Your area'}</p>
          </div>
        </div>
        <nav className="flex flex-wrap items-center gap-5 text-[12px] font-bold uppercase tracking-[0.16em] text-[#2f3a33]/65">
          <a href="#ss-visit" className="hover:text-[#5a7360]">Your visit</a>
          <a href="#ss-care" className="hover:text-[#5a7360]">Care &amp; comfort</a>
          <a href="#ss-menu" className="hover:text-[#5a7360]">Treatments</a>
        </nav>
      </header>

      {/* ------------------------------------------------ trust hero */}
      <section className="mx-auto grid max-w-6xl gap-10 px-5 py-12 @md:px-8 @md:py-16 @lg:grid-cols-[1.12fr_1fr] @lg:items-center">
        <div>
          <p className="mb-4 inline-flex items-center gap-2 rounded-full border border-[#5a7360]/30 bg-white/60 px-3 py-1 text-[11px] font-bold uppercase tracking-[0.2em]" style={{ color: MOSS }}>
            Spa &amp; massage therapy
          </p>
          <h1 className="font-savanna text-[clamp(2.1rem,5.2cqw,3.8rem)] font-semibold leading-[1.06]">
            Know exactly what to expect before you lie down.
          </h1>
          <p className="mt-5 max-w-[52ch] text-[15px] leading-relaxed text-[#2f3a33]/75">
            {b.tagline || 'Add a line about how you care for guests.'} Below you’ll find how a visit works,
            how we handle comfort and privacy, our hours and how to reach us.
          </p>
          <div className="mt-8 flex flex-wrap gap-4">
            <WhatsAppAction whatsapp={b.whatsapp} message={`Hi ${name}, I'd like to ask about a treatment.`}
              className="rounded-full bg-[#5a7360] px-6 py-3 text-sm font-bold text-white shadow-sm transition-transform hover:-translate-y-0.5" />
            <a href="#ss-hours" className="inline-flex items-center gap-2 rounded-full border-2 border-[#2f3a33]/60 px-6 py-3 text-sm font-bold transition-colors hover:bg-[#2f3a33] hover:text-[#f0f2ec]">
              See opening hours
            </a>
          </div>
        </div>

        <div className="rounded-2xl border border-[#2f3a33]/10 bg-white p-6 shadow-[0_18px_50px_-24px_rgba(47,58,51,0.4)] @md:p-8">
          <div className="flex items-center gap-4 border-b border-dashed border-[#2f3a33]/20 pb-5">
            <BrandMark logo={logo} name={name} className="h-14 w-14 text-sm" />
            <div>
              <p className="font-savanna text-xl font-semibold">{name}</p>
              <p className="text-[12px] font-bold uppercase tracking-[0.18em]" style={{ color: MOSS }}>{b.area}</p>
            </div>
          </div>
          <dl className="mt-5 space-y-4 text-sm">
            <Row icon={MapPin} label="Address" value={`${b.address || 'Add your address'}${b.area ? `, ${b.area}` : ''}`} />
            <Row icon={Phone} label="Phone" value={b.phone || 'Not added yet'} href={b.phone ? telLink(b.phone) : undefined} />
            <Row icon={Mail} label="Email" value={b.email || 'Not added yet'} href={b.email ? mailLink(b.email) : undefined} />
            <Row icon={MessageCircle} label="WhatsApp" value={b.whatsapp || 'Not added yet'} />
          </dl>
          <p className="mt-6 rounded-xl bg-[#f0f2ec] px-4 py-3 text-[12px] leading-relaxed text-[#2f3a33]/70">
            Pregnant, recovering from surgery or managing a health condition? Tell us when you enquire so we can
            advise whether a treatment is suitable — or respectfully suggest you check with your doctor first.
          </p>
        </div>
      </section>

      {/* ------------------------------------------------ how a visit works */}
      <section id="ss-visit" className="bg-[#e4eade]">
        <div className="mx-auto max-w-6xl px-5 py-14 @md:px-8">
          <div className="mb-8 flex flex-wrap items-center gap-3">
            <h2 className="font-savanna text-[clamp(1.5rem,3.2cqw,2.2rem)] font-semibold">How a visit works</h2>
            <SamplePill label="Sample guide" />
          </div>
          <ol className="grid gap-5 @md:grid-cols-2 @lg:grid-cols-4">
            {VISIT.map((v) => (
              <li key={v.n} className="rounded-2xl bg-white p-6 shadow-sm">
                <p className="font-savanna text-3xl font-semibold" style={{ color: MOSS }}>{v.n}</p>
                <h3 className="mt-3 font-savanna text-lg font-semibold">{v.t}</h3>
                <p className="mt-2 text-sm leading-relaxed text-[#2f3a33]/70">{v.d}</p>
              </li>
            ))}
          </ol>
          <p className="mt-4 text-[12px] text-[#2f3a33]/55">Replace this sample guide with your own process in the editor.</p>
        </div>
      </section>

      {/* ------------------------------------------------ care + credentials */}
      <section id="ss-care" className="mx-auto grid max-w-6xl gap-10 px-5 py-14 @md:px-8 @md:py-20 @lg:grid-cols-2">
        <div>
          <div className="mb-6 flex items-center gap-3">
            <h2 className="font-savanna text-[clamp(1.5rem,3.2cqw,2.2rem)] font-semibold">Care &amp; comfort</h2>
            <SamplePill label="Sample list" />
          </div>
          <ul className="space-y-4">
            {CARE.map((c, i) => (
              <li key={i} className="flex items-start gap-4 rounded-2xl border border-[#2f3a33]/10 bg-white px-5 py-4">
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full" style={{ background: '#f0f2ec', color: MOSS }}>
                  <c.icon className="h-4.5 w-4.5" aria-hidden />
                </span>
                <p className="pt-2 text-[15px] font-semibold">{c.text}</p>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h2 className="mb-6 font-savanna text-[clamp(1.5rem,3.2cqw,2.2rem)] font-semibold">Therapist training &amp; credentials</h2>
          {b.credentials.length > 0 ? (
            <ul className="space-y-3">
              {b.credentials.map((c, i) => (
                <li key={i} className="flex items-center gap-3 rounded-xl bg-white px-5 py-4 text-[15px] font-semibold shadow-sm">
                  <BadgeCheck className="h-5 w-5 shrink-0" style={{ color: MOSS }} /> {c}
                </li>
              ))}
            </ul>
          ) : (
            <div className="rounded-2xl border-2 border-dashed border-[#5a7360]/40 bg-white/60 p-8">
              <BadgeCheck className="h-8 w-8" style={{ color: MOSS }} aria-hidden />
              <p className="mt-3 font-savanna text-lg font-semibold">Nothing added yet — and that&apos;s honest.</p>
              <p className="mt-2 text-sm leading-relaxed text-[#2f3a33]/70">
                This design only lists real therapist qualifications, registrations or product accreditations
                that you add yourself. It never invents credentials, reviews, or claims that a treatment
                diagnoses, treats or cures anything.
              </p>
              <button type="button" onClick={() => onEditRequest?.('business')}
                className="mt-5 rounded-full px-5 py-2.5 text-sm font-bold text-white" style={{ background: MOSS }}>
                Add real credentials in the editor
              </button>
            </div>
          )}
          {feature && (
            <figure className="mt-8">
              <SmartImage src={feature.src} alt={feature.alt} className="aspect-[16/10] w-full rounded-2xl" />
              <figcaption className="mt-2 flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.18em] text-[#2f3a33]/55">
                {feature.alt} {feature.sample && <SamplePill label="Sample photo" />}
              </figcaption>
            </figure>
          )}
        </div>
      </section>

      {/* ------------------------------------------------ hours & directions */}
      <section id="ss-hours" className="bg-white">
        <div className="mx-auto max-w-6xl px-5 py-14 @md:px-8">
          <h2 className="font-savanna text-[clamp(1.5rem,3.2cqw,2.2rem)] font-semibold">Hours &amp; directions</h2>
          <div className="mt-8 grid gap-5 @md:grid-cols-3">
            <div className="rounded-2xl bg-[#f0f2ec] p-6">
              <p className="mb-4 flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-[0.22em]" style={{ color: MOSS }}>
                <Clock className="h-4 w-4" /> Opening hours
              </p>
              <ul className="space-y-3">
                {b.hours.map((h) => (
                  <li key={h.id} className="flex justify-between gap-4 border-b border-[#2f3a33]/8 pb-3 text-sm last:border-0 last:pb-0">
                    <span className="font-semibold">{h.label}</span>
                    <span className="text-[#2f3a33]/70">{h.closed ? <em>Closed</em> : formatHourRow(h)}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="rounded-2xl bg-[#f0f2ec] p-6">
              <p className="mb-4 flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-[0.22em]" style={{ color: MOSS }}>
                <MapPin className="h-4 w-4" /> Where we are
              </p>
              <p className="font-savanna text-lg font-semibold">{b.address || 'Add your address'}</p>
              <p className="text-sm text-[#2f3a33]/70">{b.area || 'Your area'}</p>
              <a href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${b.address} ${b.area}`)}`}
                target="_blank" rel="noreferrer"
                className="mt-4 inline-flex items-center gap-2 text-sm font-bold underline decoration-[#5a7360] decoration-2 underline-offset-4">
                <Navigation className="h-3.5 w-3.5" /> Get directions
              </a>
            </div>
            <div className="rounded-2xl p-6 text-white" style={{ background: BARK }}>
              <p className="mb-4 flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-[0.22em] text-white/70">
                <MessageCircle className="h-4 w-4" /> Ask first
              </p>
              <p className="text-sm leading-relaxed text-white/85">
                Unsure which treatment or length suits you? Ask — we’d rather advise than have you guess.
              </p>
              <WhatsAppAction whatsapp={b.whatsapp} message={`Hi ${name}, which treatment would you recommend?`}
                className="mt-5 inline-flex rounded-full bg-white px-5 py-2.5 text-sm font-extrabold" />
            </div>
          </div>
        </div>
      </section>

      {/* ------------------------------------------------ treatments summary */}
      <section id="ss-menu" className="mx-auto max-w-6xl px-5 py-14 @md:px-8">
        <div className="mb-8 flex flex-wrap items-center gap-3">
          <h2 className="font-savanna text-[clamp(1.5rem,3.2cqw,2.2rem)] font-semibold">Treatments</h2>
          <SamplePill label="Sample prices &amp; durations" />
        </div>
        <div className="grid gap-x-12 @md:grid-cols-2">
          {b.services.map((s) => (
            <div key={s.id} className="flex items-baseline justify-between gap-4 border-b border-[#2f3a33]/10 py-3.5">
              <p className="text-[15px] font-semibold">
                {s.name}
                <span className="ml-2 text-[11px] font-bold uppercase tracking-[0.14em] text-[#2f3a33]/45">{s.category}</span>
              </p>
              <p className="flex shrink-0 items-baseline gap-3">
                {s.duration && <span className="text-[12px] font-bold text-[#2f3a33]/50">{s.duration}</span>}
                <span className="font-savanna text-lg font-semibold" style={{ color: MOSS }}>{s.price}</span>
              </p>
            </div>
          ))}
          {b.services.length === 0 && (
            <button type="button" onClick={() => onEditRequest?.('services')}
              className="col-span-full rounded-xl border-2 border-dashed border-[#2f3a33]/25 py-10 text-sm font-bold text-[#2f3a33]/60">
              Add your treatments in the editor
            </button>
          )}
        </div>
      </section>

      <footer className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-5 py-8 text-[11px] font-bold uppercase tracking-[0.18em] text-[#2f3a33]/50 @md:px-8">
        <span>{name} · {b.area}</span>
        <span>Design: Savanna · MzansiSite demo</span>
      </footer>
    </div>
  );
}

function Row({ icon: Icon, label, value, href }: { icon: React.ComponentType<{ className?: string }>; label: string; value: string; href?: string }) {
  return (
    <div className="flex items-start gap-3">
      <span className="mt-0.5" style={{ color: MOSS }}><Icon className="h-4 w-4 shrink-0" /></span>
      <div>
        <dt className="text-[10px] font-extrabold uppercase tracking-[0.2em] text-[#2f3a33]/50">{label}</dt>
        <dd className="text-[15px] font-semibold">
          {href ? <a className="underline-offset-2 hover:underline" href={href}>{value}</a> : value}
        </dd>
      </div>
    </div>
  );
}

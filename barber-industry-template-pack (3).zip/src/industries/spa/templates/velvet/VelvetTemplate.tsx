/**
 * SPA · VELVET — hero-first (spa edition).
 * Stillness as the opening statement: near-black teal, warm stone, a single
 * calm frame and generous negative space. Durations sit beside every price.
 */
import { ArrowRight, Clock, ImagePlus, MapPin, Phone, Timer } from 'lucide-react';
import { cn } from '../../../../utils/cn';
import type { TemplateProps } from '../../../../types';
import { SmartImage } from '../../../../components/SmartImage';
import { BrandMark, SamplePill, WhatsAppAction } from '../../../../components/kit';
import { formatHourRow, telLink } from '../../../../lib/utils';

const SAND = '#c9b79c';
const enquiry = (n: string) => `Hi ${n || 'there'}, I'd like to enquire about a treatment.`;

export default function VelvetTemplate({ business: b, logo, photos, onEditRequest }: TemplateProps) {
  const name = b.name || 'Your Spa';
  const hero = photos[0];
  const frames = photos.slice(1, 4);
  const menu = b.services.slice(0, 6);
  const openDay = b.hours.find((h) => !h.closed);

  return (
    <div className="@container bg-[#0f1a1a] font-velvet text-[#ece4d8]">
      {/* ------------------------------------------------ hero */}
      <header className="relative flex min-h-[600px] flex-col @md:min-h-[740px]">
        {hero ? (
          <SmartImage src={hero.src} alt={hero.alt} eager className="absolute inset-0" imgClassName="opacity-45" />
        ) : (
          <div className="absolute inset-0 bg-[radial-gradient(120%_90%_at_60%_0%,#1d3030,transparent_65%),linear-gradient(#13201f,#0b1413)]" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0f1a1a] via-[#0f1a1a]/45 to-[#0f1a1a]/70" />

        <div className="relative flex items-center justify-between px-6 pt-6 @md:px-12 @md:pt-8">
          <div className="flex items-center gap-3">
            <BrandMark logo={logo} name={name} className="h-10 w-10 text-xs" />
            <div className="leading-tight">
              <p className="text-[11px] uppercase tracking-[0.3em] text-[#ece4d8]/70">{name}</p>
              <p className="text-[10px] uppercase tracking-[0.2em] text-[#ece4d8]/45">{b.area || 'Your area'}</p>
            </div>
          </div>
          <nav className="hidden items-center gap-8 text-[11px] uppercase tracking-[0.25em] text-[#ece4d8]/65 @md:flex">
            <a className="hover:text-[#c9b79c]" href="#sv-menu">Treatments</a>
            <a className="hover:text-[#c9b79c]" href="#sv-rooms">Rooms</a>
            <a className="hover:text-[#c9b79c]" href="#sv-visit">Visit</a>
          </nav>
        </div>

        <div className="relative mt-auto px-6 pb-14 @md:px-12 @md:pb-20">
          <p className="mb-5 flex items-center gap-3 text-[11px] uppercase tracking-[0.35em]" style={{ color: SAND }}>
            <span className="h-px w-10" style={{ background: SAND }} />
            Spa &amp; massage therapy · {b.area || 'South Africa'}
          </p>
          <h1 className="max-w-[14ch] text-[clamp(2.7rem,8.2cqw,6.2rem)] font-light leading-[1.0]">{name}</h1>
          <p className="mt-5 max-w-md font-['Inter'] text-[15px] leading-relaxed text-[#ece4d8]/75">
            {b.tagline || 'A short line about your spa goes here.'}
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-4">
            <WhatsAppAction
              whatsapp={b.whatsapp}
              message={enquiry(name)}
              label="Enquire about a treatment"
              className="bg-[#c9b79c] px-7 py-3.5 font-['Inter'] text-[13px] font-semibold uppercase tracking-[0.18em] text-[#0f1a1a] transition-transform hover:-translate-y-0.5"
            />
            <a href="#sv-menu"
              className="group inline-flex items-center gap-2 border border-[#ece4d8]/30 px-7 py-3.5 font-['Inter'] text-[13px] font-semibold uppercase tracking-[0.18em] transition-colors hover:border-[#c9b79c] hover:text-[#c9b79c]">
              See treatments <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </a>
          </div>
        </div>
      </header>

      {/* ------------------------------------------------ meta strip */}
      <section className="grid divide-y divide-[#ece4d8]/12 border-y border-[#ece4d8]/12 font-['Inter'] text-sm @sm:grid-cols-3 @sm:divide-x @sm:divide-y-0">
        {[
          { icon: MapPin, k: 'Where', v: `${b.address || 'Add your address'} · ${b.area || 'your area'}` },
          { icon: Clock, k: openDay?.label || 'Hours', v: openDay ? formatHourRow(openDay) : 'Add opening hours' },
          { icon: Phone, k: 'Phone', v: b.phone || 'Add a phone number' },
        ].map((c, i) => (
          <div key={i} className="flex items-center gap-4 px-6 py-5 @md:px-10">
            <c.icon className="h-4 w-4 shrink-0" style={{ color: SAND }} aria-hidden />
            <div>
              <p className="text-[10px] uppercase tracking-[0.25em] text-[#ece4d8]/50">{c.k}</p>
              <p className="mt-0.5 text-[#ece4d8]/85">{c.v}</p>
            </div>
          </div>
        ))}
      </section>

      {/* ------------------------------------------------ treatments */}
      <section id="sv-menu" className="px-6 py-16 @md:px-12 @md:py-24">
        <div className="mb-10 flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-[11px] uppercase tracking-[0.35em]" style={{ color: SAND }}>01 · Treatments</p>
            <h2 className="mt-3 text-[clamp(1.9rem,4.4cqw,3.3rem)] font-light leading-tight">Time, held gently.</h2>
          </div>
          <SamplePill label="Sample prices &amp; durations" className="text-[#ece4d8]/65" />
        </div>

        {menu.length === 0 ? (
          <EmptyNote onClick={() => onEditRequest?.('services')} label="No treatments yet — add your menu in the editor." />
        ) : (
          <ol className="grid gap-x-14 @lg:grid-cols-2">
            {menu.map((s, i) => (
              <li key={s.id} className="border-b border-[#ece4d8]/12 py-5">
                <div className="flex items-baseline gap-4">
                  <span className="text-xs tabular-nums" style={{ color: SAND }}>{String(i + 1).padStart(2, '0')}</span>
                  <h3 className="flex-1 text-xl font-normal @md:text-2xl">{s.name || 'Untitled treatment'}</h3>
                  {s.duration && (
                    <span className="flex items-center gap-1 font-['Inter'] text-[12px] uppercase tracking-[0.12em] text-[#ece4d8]/55">
                      <Timer className="h-3 w-3" aria-hidden /> {s.duration}
                    </span>
                  )}
                  <span className="w-20 text-right text-lg tabular-nums" style={{ color: SAND }}>{s.price || '—'}</span>
                </div>
                {s.description && <p className="mt-1 pl-8 font-['Inter'] text-[13px] leading-relaxed text-[#ece4d8]/55">{s.description}</p>}
              </li>
            ))}
          </ol>
        )}
        <p className="mt-8 font-['Inter'] text-[12.5px] italic text-[#ece4d8]/50">
          Every treatment begins with a short consultation so pressure and products suit you on the day.
        </p>
      </section>

      {/* ------------------------------------------------ rooms */}
      <section id="sv-rooms" className="border-t border-[#ece4d8]/12 px-6 py-16 @md:px-12 @md:py-20">
        <div className="mb-10 flex items-end justify-between gap-4">
          <div>
            <p className="text-[11px] uppercase tracking-[0.35em]" style={{ color: SAND }}>02 · The rooms</p>
            <h2 className="mt-3 text-[clamp(1.6rem,3.4cqw,2.5rem)] font-light">Warm light, soft linen, no rush.</h2>
          </div>
          {photos.some((p) => p.sample) && <SamplePill label="Sample photos" className="text-[#ece4d8]/65" />}
        </div>
        {photos.length === 0 ? (
          <EmptyNote onClick={() => onEditRequest?.('media')} label="No photos yet — upload your rooms in the editor." />
        ) : (
          <div className="grid gap-4 @md:grid-cols-3">
            {frames.map((p, i) => (
              <figure key={p.id} className={cn(i === 1 && '@md:mt-10', i === 2 && '@md:mt-20')}>
                <SmartImage src={p.src} alt={p.alt} className="aspect-[3/4] w-full" />
                <figcaption className="mt-3 flex items-center gap-2 font-['Inter'] text-[11px] uppercase tracking-[0.18em] text-[#ece4d8]/50">
                  <span style={{ color: SAND }}>{String(i + 1).padStart(2, '0')}</span> {p.alt}
                  {p.sample && <SamplePill label="Sample" />}
                </figcaption>
              </figure>
            ))}
          </div>
        )}
      </section>

      {/* ------------------------------------------------ visit */}
      <section id="sv-visit" className="grid border-t border-[#ece4d8]/12 @lg:grid-cols-2">
        <div className="px-6 py-14 @md:px-12">
          <p className="text-[11px] uppercase tracking-[0.35em]" style={{ color: SAND }}>03 · Visit</p>
          <h2 className="mt-3 text-[clamp(1.9rem,4cqw,3rem)] font-light leading-tight">The room is ready.</h2>
          <div className="mt-7 space-y-4 font-['Inter'] text-[15px] text-[#ece4d8]/80">
            <p className="flex gap-3"><MapPin className="mt-1 h-4 w-4 shrink-0" style={{ color: SAND }} />{b.address || 'Add your address'}{b.area ? `, ${b.area}` : ''}</p>
            {b.phone && <a href={telLink(b.phone)} className="flex gap-3 underline-offset-4 hover:underline"><Phone className="mt-1 h-4 w-4 shrink-0" style={{ color: SAND }} />{b.phone}</a>}
          </div>
          <p className="mt-6 max-w-sm font-['Inter'] text-[12.5px] leading-relaxed text-[#ece4d8]/55">
            Arrive ten minutes early if you can — enquiries are confirmed by reply, never automatically.
          </p>
          <WhatsAppAction
            whatsapp={b.whatsapp}
            message={enquiry(name)}
            label="Message the spa"
            className="mt-7 border border-[#c9b79c] px-7 py-3.5 font-['Inter'] text-[13px] font-semibold uppercase tracking-[0.18em] text-[#c9b79c] transition-colors hover:bg-[#c9b79c] hover:text-[#0f1a1a]"
          />
        </div>
        <div className="border-t border-[#ece4d8]/12 px-6 py-14 @lg:border-l @lg:border-t-0 @md:px-12">
          <p className="font-['Inter'] text-[11px] uppercase tracking-[0.3em] text-[#ece4d8]/50">Opening hours</p>
          <ul className="mt-5 divide-y divide-[#ece4d8]/12">
            {b.hours.map((h) => (
              <li key={h.id} className="flex items-baseline justify-between gap-6 py-3">
                <span className="font-['Inter'] text-sm text-[#ece4d8]/65">{h.label}</span>
                <span className="text-lg">{h.closed ? <em className="text-[#ece4d8]/45">Closed</em> : formatHourRow(h)}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <footer className="flex flex-wrap items-center justify-between gap-4 border-t border-[#ece4d8]/12 px-6 py-8 font-['Inter'] text-[11px] uppercase tracking-[0.2em] text-[#ece4d8]/45 @md:px-12">
        <span className="flex items-center gap-3"><BrandMark logo={logo} name={name} className="h-8 w-8 text-[10px]" />{name}</span>
        <span>Design: Velvet · MzansiSite demo — sample content until edited</span>
      </footer>
    </div>
  );
}

function EmptyNote({ label, onClick }: { label: string; onClick?: () => void }) {
  return (
    <button type="button" onClick={onClick}
      className="flex w-full items-center justify-center gap-3 border border-dashed border-[#ece4d8]/30 px-6 py-12 font-['Inter'] text-sm text-[#ece4d8]/60 transition-colors hover:border-[#c9b79c] hover:text-[#c9b79c]">
      <ImagePlus className="h-4 w-4" aria-hidden /> {label}
    </button>
  );
}

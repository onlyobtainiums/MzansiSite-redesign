/**
 * SPA · PRAXIS — gallery-first (spa edition).
 * A bright, airy "room tour": wide establishing frame, a calm two-column
 * stack of spaces, and duration-tagged treatments as captions.
 * Mist-white, warm greige, muted sage accent.
 */
import { ArrowDownRight, ImagePlus, Images, Phone, Timer } from 'lucide-react';
import { cn } from '../../../../utils/cn';
import type { TemplateProps } from '../../../../types';
import { SmartImage } from '../../../../components/SmartImage';
import { SamplePill, WhatsAppAction } from '../../../../components/kit';
import { formatHourRow, telLink } from '../../../../lib/utils';

const SAGE = '#7d9183';
const ASPECTS = ['aspect-[4/5]', 'aspect-square', 'aspect-[3/4]', 'aspect-[4/3]', 'aspect-[3/4]', 'aspect-square'];

export default function PraxisTemplate({ business: b, logo, photos, onEditRequest }: TemplateProps) {
  const name = b.name || 'Your Spa';
  const [featured, ...rest] = photos;
  const hasOnlySamples = photos.length > 0 && photos.every((p) => p.sample);

  return (
    <div className="@container bg-[#f7f6f3] font-praxis text-[#2b2b28]">
      {/* ------------------------------------------------ slim header */}
      <header className="sticky top-0 z-20 flex items-center justify-between border-b border-[#2b2b28]/10 bg-[#f7f6f3]/90 px-5 py-4 backdrop-blur @md:px-10">
        <p className="flex items-center gap-3 text-sm font-semibold tracking-tight">
          {logo ? (
            <img src={logo} alt="" className="h-7 w-7 rounded-full object-cover" />
          ) : (
            <span className="grid h-7 w-7 place-items-center rounded-full border text-[10px] font-bold" style={{ borderColor: SAGE, color: SAGE }}>
              {name.trim()[0]?.toUpperCase() ?? 'S'}
            </span>
          )}
          {name}
        </p>
        <div className="flex items-center gap-4 text-[12px] font-medium">
          <a href="#sp-rooms" className="hidden hover:underline @sm:inline">Rooms</a>
          <a href="#sp-treatments" className="hidden hover:underline @sm:inline">Treatments</a>
          {b.phone && (
            <a href={telLink(b.phone)} className="grid h-9 w-9 place-items-center rounded-full border border-[#2b2b28]/20" aria-label="Call the spa">
              <Phone className="h-4 w-4" />
            </a>
          )}
        </div>
      </header>

      {/* ------------------------------------------------ intro */}
      <section className="px-5 pb-8 pt-12 @md:px-10 @md:pt-16">
        <p className="mb-3 text-[11px] font-semibold uppercase tracking-[0.3em]" style={{ color: SAGE }}>
          Room tour · {name}
        </p>
        <h1 className="max-w-[20ch] text-[clamp(1.9rem,5cqw,3.8rem)] font-semibold leading-[1.05] tracking-[-0.02em]">
          See the space before you book the hour.
        </h1>
        <p className="mt-4 max-w-xl text-[15px] leading-relaxed text-[#2b2b28]/65">
          {b.tagline || 'Add your one-liner in the editor.'} Quiet rooms, fresh linen and nothing staged —
          this is the spa exactly as you’ll find it.
        </p>
        {hasOnlySamples && (
          <button type="button" onClick={() => onEditRequest?.('media')}
            className="mt-6 inline-flex items-center gap-2 rounded-full border border-dashed border-[#2b2b28]/30 px-4 py-2 text-[12px] font-semibold text-[#2b2b28]/65 transition-colors hover:border-[#7d9183] hover:text-[#7d9183]">
            <Images className="h-3.5 w-3.5" /> These are sample photos — upload your own to replace them
          </button>
        )}
      </section>

      {/* ------------------------------------------------ establishing frame */}
      {featured && (
        <figure className="px-5 @md:px-10">
          <SmartImage src={featured.src} alt={featured.alt} eager className="aspect-[16/10] w-full rounded-2xl @md:aspect-[21/9]" />
          <figcaption className="mt-3 flex flex-wrap items-center gap-3 text-[11px] font-medium uppercase tracking-[0.2em] text-[#2b2b28]/55">
            <span style={{ color: SAGE }}>Main room</span>
            <span>{featured.alt}</span>
            {featured.sample && <SamplePill label="Sample photo" />}
          </figcaption>
        </figure>
      )}

      {/* ------------------------------------------------ the rooms */}
      <section id="sp-rooms" className="px-5 py-12 @md:px-10 @md:py-16">
        {photos.length === 0 ? (
          <div className="rounded-2xl border-2 border-dashed border-[#2b2b28]/25 bg-white px-6 py-16 text-center @md:py-24">
            <span className="mx-auto grid h-14 w-14 place-items-center rounded-full" style={{ background: `${SAGE}22`, color: SAGE }}>
              <ImagePlus className="h-6 w-6" aria-hidden />
            </span>
            <h2 className="mt-5 text-2xl font-semibold tracking-tight">Your rooms go here.</h2>
            <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-[#2b2b28]/60">
              This design is built around your spaces: treatment rooms, towels, oils and candlelit corners.
              Add up to six photos in the free preview — more once you publish.
            </p>
            <button type="button" onClick={() => onEditRequest?.('media')}
              className="mt-6 rounded-full px-6 py-3 text-sm font-semibold text-white transition-transform hover:-translate-y-0.5"
              style={{ background: SAGE }}>
              Open photo uploads
            </button>
          </div>
        ) : (
          <>
            <div className="mb-6 flex items-end justify-between">
              <h2 className="text-lg font-semibold tracking-tight">Every corner</h2>
              <p className="text-[11px] font-medium uppercase tracking-[0.2em] text-[#2b2b28]/50">{photos.length} spaces</p>
            </div>
            <div className="columns-2 gap-4 @md:columns-3">
              {rest.map((p, i) => (
                <figure key={p.id} className="mb-4 break-inside-avoid">
                  <SmartImage src={p.src} alt={p.alt} className={cn('w-full rounded-xl', ASPECTS[i % ASPECTS.length])} />
                  <figcaption className="mt-2 flex items-center gap-2 text-[10px] font-medium uppercase tracking-[0.16em] text-[#2b2b28]/50">
                    <ArrowDownRight className="h-3 w-3 shrink-0" style={{ color: SAGE }} />
                    <span className="truncate">{p.alt}</span>
                    {p.sample && <span className="ml-auto shrink-0 rounded-full border border-[#2b2b28]/15 px-1.5 py-0.5 text-[9px]">Sample</span>}
                  </figcaption>
                </figure>
              ))}
            </div>
          </>
        )}
      </section>

      {/* ------------------------------------------------ treatments as captions */}
      <section id="sp-treatments" className="border-t border-[#2b2b28]/10 px-5 py-12 @md:px-10">
        <div className="mb-8 flex flex-wrap items-center gap-3">
          <h2 className="text-[clamp(1.4rem,3cqw,2rem)] font-semibold tracking-tight">What happens in these rooms</h2>
          <SamplePill label="Sample prices &amp; durations" />
        </div>
        <ul className="grid gap-x-12 @md:grid-cols-2 @lg:grid-cols-3">
          {b.services.map((s) => (
            <li key={s.id} className="border-b border-[#2b2b28]/10 py-4">
              <div className="flex items-baseline justify-between gap-3">
                <p className="text-[14px] font-semibold">{s.name}</p>
                <p className="shrink-0 text-[14px] font-semibold" style={{ color: SAGE }}>{s.price}</p>
              </div>
              {s.duration && (
                <p className="mt-0.5 flex items-center gap-1 text-[11px] font-medium uppercase tracking-[0.12em] text-[#2b2b28]/45">
                  <Timer className="h-3 w-3" aria-hidden /> {s.duration}
                </p>
              )}
              {s.description && <p className="mt-1 text-[12.5px] leading-relaxed text-[#2b2b28]/55">{s.description}</p>}
            </li>
          ))}
        </ul>
      </section>

      {/* ------------------------------------------------ details strip */}
      <section className="border-t border-[#2b2b28]/10 bg-white px-5 py-10 @md:px-10">
        <div className="flex flex-wrap items-center gap-x-10 gap-y-6 text-sm">
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-[0.25em] text-[#2b2b28]/45">Hours</p>
            <p className="mt-1 font-medium">
              {b.hours.map((h) => `${h.label}: ${h.closed ? 'Closed' : formatHourRow(h)}`).join('  ·  ') || 'Add opening hours'}
            </p>
          </div>
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-[0.25em] text-[#2b2b28]/45">Where</p>
            <p className="mt-1 font-medium">{b.address || 'Add your address'}{b.area ? `, ${b.area}` : ''}</p>
          </div>
        </div>
        <div className="mt-8 flex flex-wrap items-center justify-between gap-4 border-t border-[#2b2b28]/10 pt-8">
          <p className="text-lg font-semibold tracking-tight">Found your room? Enquire — we confirm your time by reply.</p>
          <WhatsAppAction whatsapp={b.whatsapp} message={`Hi ${name}, I'd like to enquire about a treatment.`}
            className="rounded-full bg-[#7d9183] px-6 py-3 text-sm font-semibold text-white transition-transform hover:-translate-y-0.5"
            label="Enquire on WhatsApp" />
        </div>
      </section>

      <footer className="flex flex-wrap items-center justify-between gap-3 px-5 py-6 text-[11px] font-medium uppercase tracking-[0.18em] text-[#2b2b28]/45 @md:px-10">
        <span>{name}</span>
        <span>Design: Praxis · MzansiSite demo</span>
      </footer>
    </div>
  );
}

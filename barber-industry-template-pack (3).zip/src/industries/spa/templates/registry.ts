import type { FamilyDef } from '../../types';
import VelvetTemplate from './velvet/VelvetTemplate';
import ForgeTemplate from './forge/ForgeTemplate';
import SavannaTemplate from './savanna/SavannaTemplate';
import PraxisTemplate from './praxis/PraxisTemplate';
import MarketTemplate from './market/MarketTemplate';
import VitalTemplate from './vital/VitalTemplate';

export const TEMPLATES: FamilyDef[] = [
  {
    id: 'velvet',
    name: 'Velvet',
    strategy: 'Hero-first',
    blurb: 'Stillness as the opening statement — deep teal, warm stone, one calm frame, durations beside every price.',
    chips: ['#0f1a1a', '#ece4d8', '#c9b79c'],
    component: VelvetTemplate,
  },
  {
    id: 'forge',
    name: 'Forge',
    strategy: 'Services-first',
    blurb: 'A clear treatment matrix: filter by length, read duration and price in one row. Clay, ink and teal.',
    chips: ['#efece5', '#16211f', '#0e7c76'],
    component: ForgeTemplate,
  },
  {
    id: 'savanna',
    name: 'Savanna',
    strategy: 'Trust-first',
    blurb: 'How a visit works, comfort and privacy practices, and an honest health note before anything is sold.',
    chips: ['#f0f2ec', '#2f3a33', '#5a7360'],
    component: SavannaTemplate,
  },
  {
    id: 'praxis',
    name: 'Praxis',
    strategy: 'Gallery-first',
    blurb: 'A bright room tour — wide establishing frame, airy grid of spaces, duration-tagged treatments.',
    chips: ['#f7f6f3', '#2b2b28', '#7d9183'],
    component: PraxisTemplate,
  },
  {
    id: 'market',
    name: 'Market',
    strategy: 'About-first',
    blurb: 'Your philosophy in a slow vertical rhythm: ivory paper, wide margins, pull-quotes, then treatments.',
    chips: ['#fbf8f3', '#3a2d2a', '#a9704f'],
    component: MarketTemplate,
  },
  {
    id: 'vital',
    name: 'Vital',
    strategy: 'Enquiry-first',
    blurb: 'A treatment enquiry leads: treatment, length, pressure and health notes drafted into one message.',
    chips: ['#f2f5f3', '#123b3a', '#1faf57'],
    component: VitalTemplate,
  },
];

/**
 * SPA · MARKET — about-first (spa edition).
 * The philosophy leads, set as a slow vertical rhythm with wide margins and
 * pull-quotes. Ivory paper, deep plum-brown ink, soft copper rules.
 */
import { ArrowRight, Clock, Mail, MapPin, PenLine, Phone, Quote, Timer } from 'lucide-react';
import type { TemplateProps } from '../../../../types';
import { SmartImage } from '../../../../components/SmartImage';
import { BrandMark, SamplePill, WhatsAppAction } from '../../../../components/kit';
import { formatHourRow, mailLink, paragraphs, telLink } from '../../../../lib/utils';

const COPPER = '#a9704f';
const INK = '#3a2d2a';

export default function MarketTemplate({ business: b, logo, photos, onEditRequest }: TemplateProps) {
  const name = b.name || 'Your Spa';
  const paras = paragraphs(b.description);
  const wide = photos[1] ?? photos[0];
  const pair = photos.slice(2, 4);

  return (
    <div className="@container bg-[#fbf8f3] font-market-sans text-[#3a2d2a]">
      {/* ------------------------------------------------ masthead */}
      <header className="border-b border-[#3a2d2a]/12 px-5 py-6 @md:px-10">
        <div className="mx-auto flex max-w-4xl flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <BrandMark logo={logo} name={name} className="h-11 w-11 text-xs" />
            <div className="leading-tight">
              <p className="font-market text-xl font-semibold">{name}</p>
              <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-[#3a2d2a]/55">{b.area || 'Your area'}</p>
            </div>
          </div>
          <WhatsAppAction whatsapp={b.whatsapp} message={`Hi ${name}, I'd like to enquire about a treatment.`}
            className="rounded-full bg-[#3a2d2a] px-5 py-2.5 text-sm font-semibold text-[#fbf8f3] transition-transform hover:-translate-y-0.5"
            label="Enquire" />
        </div>
      </header>

      <main className="mx-auto max-w-4xl px-5 @md:px-10">
        {/* ------------------------------------------------ philosophy */}
        <section className="py-16 text-center @md:py-24">
          <p className="mb-6 inline-flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.3em]" style={{ color: COPPER }}>
            <span className="h-px w-8" style={{ background: COPPER }} /> Our philosophy <span className="h-px w-8" style={{ background: COPPER }} />
          </p>
          <h1 className="mx-auto max-w-[20ch] font-market text-[clamp(2rem,5.4cqw,3.8rem)] font-semibold leading-[1.12]">
            {b.tagline || 'Rest is not a luxury. It is maintenance.'}
          </h1>

          {paras.length === 0 ? (
            <button type="button" onClick={() => onEditRequest?.('business')}
              className="mx-auto mt-10 block w-full max-w-xl rounded-2xl border-2 border-dashed border-[#3a2d2a]/25 bg-white/60 px-6 py-12 text-left">
              <p className="flex items-center gap-2 font-market text-xl font-semibold" style={{ color: COPPER }}>
                <PenLine className="h-5 w-5" /> Write your philosophy here
              </p>
              <p className="mt-2 text-sm leading-relaxed text-[#3a2d2a]/70">
                Why did you open the spa? What do you believe a good treatment should feel like?
                What should a nervous first-timer know? Add it in the editor.
              </p>
            </button>
          ) : (
            <div className="mx-auto mt-10 max-w-2xl space-y-6 text-left">
              {paras.map((p, i) => (
                <p key={i} className="font-market text-[1.1rem] leading-[1.85] text-[#3a2d2a]/85 first:text-center first:text-[1.25rem] first:italic">
                  {p}
                </p>
              ))}
              <div className="flex justify-center"><SamplePill label="Sample text — edit in 'Business'" /></div>
            </div>
          )}
        </section>

        {/* ------------------------------------------------ wide plate */}
        {wide && (
          <figure className="pb-16">
            <SmartImage src={wide.src} alt={wide.alt} className="aspect-[21/9] w-full rounded-sm" />
            <figcaption className="mt-3 text-center text-[11px] font-semibold uppercase tracking-[0.2em] text-[#3a2d2a]/50">
              {wide.alt} {wide.sample && <SamplePill label="Sample photo" className="ml-1" />}
            </figcaption>
          </figure>
        )}

        {/* ------------------------------------------------ pull quote */}
        <section className="border-y border-[#3a2d2a]/15 py-14 text-center">
          <Quote className="mx-auto h-7 w-7" style={{ color: COPPER }} aria-hidden />
          <p className="mx-auto mt-5 max-w-[26ch] font-market text-[clamp(1.4rem,3.6cqw,2.3rem)] font-semibold italic leading-snug">
            “An hour without a phone is the whole treatment.”
          </p>
          <p className="mt-4 text-[11px] font-semibold uppercase tracking-[0.22em] text-[#3a2d2a]/45">Sample quote — replace with your own words</p>
        </section>

        {/* ------------------------------------------------ pair of plates */}
        {pair.length > 0 && (
          <section className="grid gap-5 py-14 @sm:grid-cols-2">
            {pair.map((p) => (
              <figure key={p.id}>
                <SmartImage src={p.src} alt={p.alt} className="aspect-[4/5] w-full rounded-sm" />
                <figcaption className="mt-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-[#3a2d2a]/50">{p.alt}</figcaption>
              </figure>
            ))}
          </section>
        )}

        {/* ------------------------------------------------ treatments */}
        <section className="border-t border-[#3a2d2a]/15 py-14">
          <div className="mb-8 text-center">
            <h2 className="font-market text-[clamp(1.5rem,3.6cqw,2.4rem)] font-semibold">What we offer</h2>
            <div className="mt-2 flex justify-center"><SamplePill label="Sample prices &amp; durations" /></div>
          </div>
          <ul className="mx-auto max-w-2xl">
            {b.services.map((s) => (
              <li key={s.id} className="flex flex-wrap items-baseline gap-x-4 gap-y-1 border-b border-dashed border-[#3a2d2a]/20 py-4 last:border-0">
                <span className="min-w-0 flex-1">
                  <span className="font-market text-lg font-semibold">{s.name}</span>
                  {s.description && <span className="block text-[13px] leading-relaxed text-[#3a2d2a]/60">{s.description}</span>}
                </span>
                {s.duration && (
                  <span className="inline-flex items-center gap-1 text-[12px] font-semibold text-[#3a2d2a]/55">
                    <Timer className="h-3 w-3" aria-hidden /> {s.duration}
                  </span>
                )}
                <span className="w-20 text-right font-market text-lg font-semibold" style={{ color: COPPER }}>{s.price}</span>
              </li>
            ))}
            {b.services.length === 0 && (
              <li className="py-10 text-center text-sm text-[#3a2d2a]/60">No treatments yet — add your menu in the editor.</li>
            )}
          </ul>
        </section>

        {/* ------------------------------------------------ visit */}
        <section className="grid gap-5 border-t border-[#3a2d2a]/15 py-14 @md:grid-cols-2">
          <div className="rounded-sm border border-[#3a2d2a]/20 bg-white/70 p-6">
            <p className="mb-3 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.2em] text-[#3a2d2a]/55">
              <Clock className="h-3.5 w-3.5" /> Opening hours
            </p>
            <ul className="space-y-2.5">
              {b.hours.map((h) => (
                <li key={h.id} className="flex justify-between gap-4 text-sm">
                  <span className="font-semibold">{h.label}</span>
                  <span>{h.closed ? <em className="text-[#3a2d2a]/50">Closed</em> : formatHourRow(h)}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-sm border border-[#3a2d2a]/20 bg-white/70 p-6">
            <p className="mb-3 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.2em] text-[#3a2d2a]/55">
              <MapPin className="h-3.5 w-3.5" /> Find us
            </p>
            <p className="font-market text-lg font-semibold">{b.address || 'Add your address'}</p>
            <p className="text-sm text-[#3a2d2a]/65">{b.area || 'Your area'}</p>
            <div className="mt-4 space-y-2 border-t border-dashed border-[#3a2d2a]/20 pt-4 text-sm">
              {b.phone && <a href={telLink(b.phone)} className="flex items-center gap-2 font-semibold hover:underline"><Phone className="h-3.5 w-3.5" /> {b.phone}</a>}
              {b.email && <a href={mailLink(b.email)} className="flex items-center gap-2 font-semibold hover:underline"><Mail className="h-3.5 w-3.5" /> {b.email}</a>}
            </div>
            <a href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${b.address} ${b.area}`)}`}
              target="_blank" rel="noreferrer"
              className="mt-4 inline-flex items-center gap-1.5 text-sm font-bold" style={{ color: COPPER }}>
              Open in Maps <ArrowRight className="h-3.5 w-3.5" />
            </a>
          </div>
        </section>

        {/* ------------------------------------------------ closing */}
        <section className="mb-16 rounded-sm px-6 py-12 text-center text-[#fbf8f3]" style={{ background: INK }}>
          <p className="font-market text-[clamp(1.4rem,3.4cqw,2.2rem)] font-semibold italic leading-snug">
            When you’re ready, send a message. We’ll find you an hour.
          </p>
          <WhatsAppAction whatsapp={b.whatsapp} message={`Hi ${name}, I'd like to enquire about a treatment.`}
            className="mt-6 rounded-full bg-[#fbf8f3] px-7 py-3 text-sm font-semibold text-[#3a2d2a] transition-transform hover:-translate-y-0.5"
            label="Start with a message" />
          <p className="mt-4 text-[11px] uppercase tracking-[0.2em] text-[#fbf8f3]/55">
            Enquiries are answered during opening hours — and confirmed by reply, never automatically
          </p>
        </section>
      </main>

      <footer className="border-t border-[#3a2d2a]/12 px-5 py-6 text-center text-[11px] font-semibold uppercase tracking-[0.2em] text-[#3a2d2a]/45">
        {name} · Design: Market · MzansiSite demo — text and prices are samples until edited
      </footer>
    </div>
  );
}

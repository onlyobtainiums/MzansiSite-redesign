/**
 * SPA · FORGE — services-first (spa edition).
 * A clinical, legible treatment matrix: filter by duration band, read price
 * and length in one row. Clay/linen palette, deep ink, one clear teal accent.
 */
import { useMemo, useState } from 'react';
import { ArrowUpRight, Clock3, Hourglass, Mail, MapPin, Phone, Timer } from 'lucide-react';
import { cn } from '../../../../utils/cn';
import type { TemplateProps } from '../../../../types';
import { SmartImage } from '../../../../components/SmartImage';
import { BrandMark, SamplePill, WhatsAppAction } from '../../../../components/kit';
import { formatHourRow, mailLink, telLink } from '../../../../lib/utils';

const TEAL = '#0e7c76';
const mins = (d?: string) => parseInt(String(d ?? '').replace(/\D/g, ''), 10) || 0;

const BANDS = [
  { id: 'all', label: 'All lengths', test: () => true },
  { id: 'short', label: 'Up to 45 min', test: (m: number) => m > 0 && m <= 45 },
  { id: 'hour', label: '46 – 75 min', test: (m: number) => m > 45 && m <= 75 },
  { id: 'long', label: '76 min +', test: (m: number) => m > 75 },
];

export default function ForgeTemplate({ business: b, logo, photos, onEditRequest }: TemplateProps) {
  const name = b.name || 'Your Spa';
  const [band, setBand] = useState('all');
  const [cat, setCat] = useState('All');

  const categories = useMemo(
    () => ['All', ...Array.from(new Set(b.services.map((s) => s.category || 'Other')))],
    [b.services],
  );
  const active = BANDS.find((x) => x.id === band) ?? BANDS[0];
  const shown = b.services.filter(
    (s) => (cat === 'All' || (s.category || 'Other') === cat) && active.test(mins(s.duration)),
  );
  const openDay = b.hours.find((h) => !h.closed);

  return (
    <div className="@container bg-[#efece5] font-forge text-[#16211f]">
      {/* ------------------------------------------------ utility bar */}
      <div className="flex flex-wrap items-center justify-between gap-x-6 gap-y-1 bg-[#16211f] px-5 py-2.5 text-[11px] font-medium uppercase tracking-[0.18em] text-[#efece5]/85 @md:px-10">
        <span className="flex items-center gap-2">
          <span className="inline-block h-2 w-2 rounded-full" style={{ background: TEAL }} />
          Treatment enquiries
        </span>
        <span className="hidden @sm:inline">{openDay ? `${openDay.label} · ${formatHourRow(openDay)}` : 'Add opening hours'}</span>
        <a href="#sf-menu" className="underline decoration-[#0e7c76] decoration-2 underline-offset-4 hover:text-white">Treatment list</a>
      </div>

      {/* ------------------------------------------------ masthead */}
      <header className="border-b-2 border-[#16211f] px-5 pb-8 pt-10 @md:px-10 @md:pt-14">
        <div className="flex flex-wrap items-start justify-between gap-6">
          <div className="min-w-0">
            <p className="mb-3 flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.3em] text-[#16211f]/55">
              <Hourglass className="h-3.5 w-3.5" aria-hidden /> Spa &amp; massage — {b.area || 'South Africa'}
            </p>
            <h1 className="text-[clamp(2.3rem,7.2cqw,5.2rem)] font-extrabold uppercase leading-[0.92] tracking-[-0.02em]">{name}</h1>
          </div>
          <div className="flex items-center gap-4">
            <p className="max-w-[26ch] text-right text-sm font-medium leading-snug text-[#16211f]/65 @max-md:text-left">
              {b.tagline || 'Add your spa’s one-liner in the editor.'}
            </p>
            <BrandMark logo={logo} name={name} className="h-14 w-14 rounded-none border-2 text-sm" />
          </div>
        </div>
      </header>

      {/* ------------------------------------------------ the matrix */}
      <main id="sf-menu" className="px-5 py-12 @md:px-10 @md:py-16">
        <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="font-prices text-[12px] font-semibold uppercase tracking-[0.3em]" style={{ color: TEAL }}>
              Treatments · durations · prices
            </p>
            <h2 className="mt-2 text-[clamp(1.7rem,4cqw,2.8rem)] font-extrabold uppercase leading-none">The Treatment List</h2>
          </div>
          <SamplePill label="Sample list &amp; prices" />
        </div>

        {/* duration band filter */}
        <div className="mb-4 flex flex-wrap gap-2" role="tablist" aria-label="Filter by treatment length">
          {BANDS.map((x) => (
            <button key={x.id} role="tab" aria-selected={band === x.id} onClick={() => setBand(x.id)}
              className={cn(
                'inline-flex items-center gap-1.5 border-2 border-[#16211f] px-4 py-1.5 text-[12px] font-bold uppercase tracking-[0.12em] transition-colors',
                band === x.id ? 'bg-[#16211f] text-[#efece5]' : 'hover:bg-[#16211f]/10',
              )}>
              <Timer className="h-3.5 w-3.5" aria-hidden /> {x.label}
            </button>
          ))}
        </div>
        {/* category filter */}
        <div className="mb-10 flex flex-wrap gap-2" role="tablist" aria-label="Filter by category">
          {categories.map((c) => (
            <button key={c} role="tab" aria-selected={cat === c} onClick={() => setCat(c)}
              className={cn(
                'rounded-full border px-3.5 py-1 text-[12px] font-bold transition-colors',
                cat === c ? 'border-transparent bg-[#0e7c76] text-white' : 'border-[#16211f]/30 text-[#16211f]/70 hover:border-[#16211f]',
              )}>
              {c}
            </button>
          ))}
        </div>

        {shown.length === 0 ? (
          <button type="button" onClick={() => onEditRequest?.('services')}
            className="w-full border-2 border-dashed border-[#16211f]/40 px-6 py-14 text-center text-sm font-semibold uppercase tracking-[0.14em] text-[#16211f]/60 hover:border-[#0e7c76] hover:text-[#0e7c76]">
            Nothing matches this filter — adjust it, or add treatments in the editor
          </button>
        ) : (
          <div className="border-2 border-[#16211f] bg-white">
            {/* matrix header */}
            <div className="hidden grid-cols-[1fr_120px_120px] gap-4 border-b-2 border-[#16211f] bg-[#efece5] px-5 py-2.5 font-prices text-[11px] font-bold uppercase tracking-[0.18em] @md:grid">
              <span>Treatment</span><span className="text-center">Duration</span><span className="text-right">From</span>
            </div>
            <ol>
              {shown.map((s) => (
                <li key={s.id} className="grid gap-x-4 gap-y-1 border-b border-[#16211f]/12 px-5 py-4 last:border-0 @md:grid-cols-[1fr_120px_120px] @md:items-baseline">
                  <div>
                    <h3 className="text-[15px] font-bold uppercase tracking-[0.04em]">{s.name || 'Untitled treatment'}</h3>
                    {s.description && <p className="mt-1 max-w-[54ch] text-[13px] leading-relaxed text-[#16211f]/60">{s.description}</p>}
                    <span className="mt-1 inline-block rounded-full bg-[#efece5] px-2 py-0.5 text-[10px] font-bold uppercase tracking-[0.14em] text-[#16211f]/60 @md:hidden">
                      {s.category}
                    </span>
                  </div>
                  <p className="font-prices text-[13px] font-semibold text-[#16211f]/70 @md:text-center">
                    {s.duration ? <span className="inline-flex items-center gap-1"><Timer className="h-3 w-3" aria-hidden />{s.duration}</span> : '—'}
                  </p>
                  <p className="font-prices text-lg font-semibold @md:text-right" style={{ color: TEAL }}>{s.price || '—'}</p>
                </li>
              ))}
            </ol>
          </div>
        )}

        <p className="mt-4 text-[12px] font-semibold text-[#16211f]/55">
          Durations include consultation and dressing time. Final pricing is confirmed when you enquire.
        </p>

        {/* enquiry band */}
        <div className="mt-12 flex flex-wrap items-center justify-between gap-6 bg-[#16211f] px-6 py-8 text-[#efece5] @md:px-10">
          <div>
            <p className="font-prices text-[11px] uppercase tracking-[0.3em] text-[#efece5]/55">Ready when you are</p>
            <p className="mt-1 text-xl font-extrabold uppercase">Send an enquiry — we reply to confirm a time.</p>
            <p className="mt-1 text-[12px] text-[#efece5]/55">An enquiry is not a booking until the spa confirms it with you.</p>
          </div>
          <WhatsAppAction whatsapp={b.whatsapp} message={`Hi ${name}, I'd like to enquire about a treatment.`}
            label="Enquire on WhatsApp"
            className="bg-[#0e7c76] px-6 py-3.5 text-[13px] font-extrabold uppercase tracking-[0.16em] text-white transition-transform hover:-translate-y-0.5" />
        </div>
      </main>

      {/* ------------------------------------------------ info cards */}
      <section className="grid gap-px border-y-2 border-[#16211f] bg-[#16211f] @md:grid-cols-3">
        <Card icon={Clock3} title="Hours">
          <ul className="space-y-2">
            {b.hours.map((h) => (
              <li key={h.id} className="flex justify-between gap-4 font-prices text-[13px]">
                <span className="text-[#16211f]/55">{h.label}</span>
                <span className="font-semibold">{h.closed ? 'Closed' : formatHourRow(h)}</span>
              </li>
            ))}
          </ul>
        </Card>
        <Card icon={MapPin} title="Find us">
          <p className="text-sm font-semibold">{b.address || 'Add your address'}</p>
          <p className="text-sm text-[#16211f]/60">{b.area || 'Your area'}</p>
          {b.phone && (
            <a href={telLink(b.phone)} className="mt-3 inline-flex items-center gap-2 text-sm font-bold underline decoration-[#0e7c76] decoration-2 underline-offset-4">
              <Phone className="h-3.5 w-3.5" /> {b.phone}
            </a>
          )}
        </Card>
        <Card icon={Mail} title="Enquiries">
          <p className="text-sm leading-relaxed text-[#16211f]/65">
            Message or email us about treatment length, pressure preferences, gift vouchers or couples rooms.
          </p>
          {b.email && (
            <a href={mailLink(b.email)} className="mt-3 inline-flex items-center gap-2 text-sm font-bold underline decoration-[#0e7c76] decoration-2 underline-offset-4">
              {b.email} <ArrowUpRight className="h-3.5 w-3.5" />
            </a>
          )}
        </Card>
      </section>

      {/* ------------------------------------------------ photo strip */}
      {photos.length > 0 && (
        <section className="px-5 py-12 @md:px-10">
          <div className="mb-5 flex items-center justify-between">
            <p className="font-prices text-[11px] font-semibold uppercase tracking-[0.3em] text-[#16211f]/55">Inside the spa</p>
            {photos.some((p) => p.sample) && <SamplePill label="Sample photos" />}
          </div>
          <div className="mz-frame-scroll flex snap-x gap-4 overflow-x-auto pb-3">
            {photos.map((p, i) => (
              <figure key={p.id} className="w-[240px] shrink-0 snap-start @md:w-[300px]">
                <SmartImage src={p.src} alt={p.alt} className="aspect-[4/3] w-full border-2 border-[#16211f]" />
                <figcaption className="mt-2 font-prices text-[11px] uppercase tracking-[0.14em] text-[#16211f]/55">
                  {String(i + 1).padStart(2, '0')} / {p.alt}
                </figcaption>
              </figure>
            ))}
          </div>
        </section>
      )}

      <footer className="flex flex-wrap items-center justify-between gap-3 border-t-2 border-[#16211f] px-5 py-6 text-[11px] font-bold uppercase tracking-[0.2em] text-[#16211f]/55 @md:px-10">
        <span>{name}</span>
        <span>Design: Forge · MzansiSite demo — durations &amp; prices are samples</span>
      </footer>
    </div>
  );
}

function Card({ icon: Icon, title, children }: { icon: React.ComponentType<{ className?: string }>; title: string; children: React.ReactNode }) {
  return (
    <div className="bg-[#efece5] p-6 @md:p-8">
      <p className="mb-4 flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-[0.25em]">
        <Icon className="h-4 w-4" aria-hidden /> {title}
      </p>
      {children}
    </div>
  );
}

/**
 * SPA · VITAL — enquiry-first (spa edition).
 * A treatment enquiry leads: treatment, duration, pressure preference and a
 * health-note field, composed into one WhatsApp message.
 *
 * It never books, holds or confirms an appointment, never claims availability,
 * and never offers medical advice — the spa confirms everything by reply.
 */
import { useMemo, useState } from 'react';
import {
  Check, Clock, Copy, HeartPulse, Info, Mail, MapPin, MessageCircle, Phone, Send, ShieldCheck, Timer,
} from 'lucide-react';
import { cn } from '../../../../utils/cn';
import type { TemplateProps } from '../../../../types';
import { SmartImage } from '../../../../components/SmartImage';
import { BrandMark, SamplePill } from '../../../../components/kit';
import { formatHourRow, mailLink, telLink, waLink } from '../../../../lib/utils';

const DEEP = '#123b3a';
const WA = '#1faf57';
const PRESSURE = ['Light', 'Medium', 'Firm', 'Not sure'];

export default function VitalTemplate({ business: b, logo, photos }: TemplateProps) {
  const name = b.name || 'Your Spa';
  const hasWa = b.whatsapp.replace(/[^\d]/g, '').length >= 10;
  const openDay = b.hours.find((h) => !h.closed);

  const [clientName, setClientName] = useState('');
  const [treatment, setTreatment] = useState('');
  const [duration, setDuration] = useState('');
  const [pressure, setPressure] = useState('');
  const [when, setWhen] = useState('');
  const [health, setHealth] = useState('');
  const [errors, setErrors] = useState<{ name?: string; treatment?: string }>({});
  const [drafted, setDrafted] = useState(false);
  const [copied, setCopied] = useState(false);

  const treatments = useMemo(
    () => Array.from(new Set(b.services.map((s) => s.name).filter(Boolean))),
    [b.services],
  );
  // durations offered for the chosen treatment (falls back to all known lengths)
  const durations = useMemo(() => {
    const forTreatment = b.services.filter((s) => s.name === treatment).map((s) => s.duration).filter(Boolean);
    const all = b.services.map((s) => s.duration).filter(Boolean);
    return Array.from(new Set((forTreatment.length ? forTreatment : all) as string[]));
  }, [b.services, treatment]);

  const composed = useMemo(() => {
    const lines = [
      `Hi ${name}, new treatment enquiry from the website:`,
      `• Name: ${clientName || '—'}`,
      treatment ? `• Treatment: ${treatment}` : null,
      duration ? `• Preferred length: ${duration}` : null,
      pressure ? `• Pressure preference: ${pressure}` : null,
      when ? `• Preferred day/time: ${when}` : null,
      health ? `• Health notes: ${health}` : null,
      '(This is an enquiry, not a booking — please reply to confirm availability.)',
    ].filter(Boolean);
    return lines.join('\n');
  }, [clientName, treatment, duration, pressure, when, health, name]);

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const errs: typeof errors = {};
    if (!clientName.trim()) errs.name = 'Please add your name so the spa knows who is asking.';
    if (!treatment) errs.treatment = 'Choose a treatment, or “Not sure yet”.';
    setErrors(errs);
    if (Object.keys(errs).length) return;
    window.open(waLink(b.whatsapp, composed), '_blank', 'noopener');
    setDrafted(true);
  }

  async function copy() {
    try {
      await navigator.clipboard.writeText(composed);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      window.prompt('Copy your enquiry:', composed);
    }
  }

  return (
    <div className="@container bg-[#f2f5f3] font-vital text-[#123b3a]">
      {/* ------------------------------------------------ top bar */}
      <header className="flex flex-wrap items-center justify-between gap-3 px-5 py-4 @md:px-10">
        <p className="flex items-center gap-2.5 text-[15px] font-extrabold tracking-tight">
          <BrandMark logo={logo} name={name} className="h-9 w-9 text-[10px]" />
          {name}
        </p>
        <div className="flex items-center gap-4 text-[12px] font-semibold text-[#123b3a]/70">
          <span className="hidden @sm:inline">{openDay ? `${openDay.label} · ${formatHourRow(openDay)}` : 'Add opening hours'}</span>
          {b.phone && (
            <a href={telLink(b.phone)} className="grid h-9 w-9 place-items-center rounded-full border border-[#123b3a]/25" aria-label="Phone the spa">
              <Phone className="h-4 w-4" />
            </a>
          )}
        </div>
      </header>

      <main className="px-5 pb-14 pt-6 @md:px-10 @md:pt-10">
        <div className="grid gap-10 @lg:grid-cols-[1fr_1fr] @lg:items-start">
          {/* contact panel */}
          <div>
            <p className="mb-4 inline-flex items-center gap-2 rounded-full px-3 py-1 text-[11px] font-bold uppercase tracking-[0.2em] text-white" style={{ background: DEEP }}>
              <MessageCircle className="h-3.5 w-3.5" aria-hidden /> Treatment enquiry · {b.area || 'your area'}
            </p>
            <h1 className="text-[clamp(2rem,5.2cqw,3.7rem)] font-extrabold leading-[1.02] tracking-[-0.02em]">
              Tell us what you need. We’ll find the hour.
            </h1>
            <p className="mt-4 max-w-[48ch] text-[15px] leading-relaxed text-[#123b3a]/70">
              {b.tagline || 'Add your one-liner in the editor.'} Send your treatment, preferred length and
              pressure — we reply during opening hours to confirm a time that works.
            </p>

            <div className="mt-8 max-w-md space-y-3">
              {hasWa ? (
                <a href={waLink(b.whatsapp, `Hi ${name}, I'd like to enquire about a treatment.`)}
                  target="_blank" rel="noreferrer"
                  className="flex items-center gap-3 rounded-2xl px-5 py-4 text-white shadow-lg shadow-[#1faf57]/25 transition-transform hover:-translate-y-0.5"
                  style={{ background: WA }}>
                  <MessageCircle className="h-6 w-6 shrink-0" aria-hidden />
                  <span>
                    <span className="block text-[15px] font-extrabold">WhatsApp us · {b.whatsapp}</span>
                    <span className="block text-[12px] font-medium text-white/80">Fastest way to check this week’s availability</span>
                  </span>
                </a>
              ) : (
                <p className="rounded-2xl border-2 border-dashed border-[#123b3a]/30 px-5 py-4 text-sm font-semibold text-[#123b3a]/60">
                  Add your WhatsApp number in the editor to switch this button live.
                </p>
              )}
              <div className="grid grid-cols-2 gap-3">
                {b.phone ? (
                  <a href={telLink(b.phone)} className="flex items-center gap-2.5 rounded-2xl border border-[#123b3a]/25 bg-white px-4 py-3.5 text-[13px] font-bold transition-colors hover:border-[#123b3a]">
                    <Phone className="h-4 w-4 shrink-0" /> {b.phone}
                  </a>
                ) : (
                  <span className="flex items-center gap-2.5 rounded-2xl border border-dashed border-[#123b3a]/25 px-4 py-3.5 text-[13px] font-semibold text-[#123b3a]/50">
                    <Phone className="h-4 w-4" /> Phone not added
                  </span>
                )}
                {b.email ? (
                  <a href={mailLink(b.email)} className="flex items-center gap-2.5 rounded-2xl border border-[#123b3a]/25 bg-white px-4 py-3.5 text-[13px] font-bold transition-colors hover:border-[#123b3a]">
                    <Mail className="h-4 w-4 shrink-0" /> Email us
                  </a>
                ) : (
                  <span className="flex items-center gap-2.5 rounded-2xl border border-dashed border-[#123b3a]/25 px-4 py-3.5 text-[13px] font-semibold text-[#123b3a]/50">
                    <Mail className="h-4 w-4" /> Email not added
                  </span>
                )}
              </div>
            </div>

            <ul className="mt-7 space-y-2.5 text-[13px] font-semibold text-[#123b3a]/75">
              <li className="flex items-center gap-2.5"><ShieldCheck className="h-4 w-4" style={{ color: WA }} /> An enquiry is not a booking — the spa confirms by reply.</li>
              <li className="flex items-center gap-2.5"><Clock className="h-4 w-4" style={{ color: WA }} /> We answer on open days only (listed below).</li>
              <li className="flex items-center gap-2.5"><Info className="h-4 w-4" style={{ color: WA }} /> No payment is taken through this page.</li>
              <li className="flex items-center gap-2.5"><HeartPulse className="h-4 w-4" style={{ color: WA }} /> We give treatment guidance, not medical advice.</li>
            </ul>
          </div>

          {/* enquiry form */}
          <form onSubmit={submit} noValidate className="rounded-2xl border border-[#123b3a]/15 bg-white p-6 shadow-[0_24px_60px_-30px_rgba(18,59,58,0.4)] @md:p-8">
            <h2 className="text-xl font-extrabold tracking-tight">Treatment enquiry</h2>
            <p className="mt-1 text-[12.5px] text-[#123b3a]/60">
              Fill this in and we’ll open WhatsApp with your enquiry drafted. Nothing sends until you press send.
            </p>

            <label className="mt-6 block">
              <span className="mb-1.5 block text-[11px] font-extrabold uppercase tracking-[0.16em] text-[#123b3a]/70">Your name *</span>
              <input value={clientName}
                onChange={(e) => { setClientName(e.target.value); if (errors.name) setErrors({ ...errors, name: undefined }); }}
                placeholder="e.g. Thandi M."
                className={cn('w-full rounded-xl border bg-[#f2f5f3] px-4 py-3 text-sm outline-none transition-colors focus:border-[#1faf57]', errors.name ? 'border-red-400' : 'border-[#123b3a]/20')}
                aria-invalid={!!errors.name} />
              {errors.name && <span className="mt-1 block text-[12px] font-semibold text-red-600">{errors.name}</span>}
            </label>

            <label className="mt-5 block">
              <span className="mb-1.5 block text-[11px] font-extrabold uppercase tracking-[0.16em] text-[#123b3a]/70">Treatment *</span>
              <select value={treatment}
                onChange={(e) => { setTreatment(e.target.value); setDuration(''); if (errors.treatment) setErrors({ ...errors, treatment: undefined }); }}
                className={cn('w-full rounded-xl border bg-[#f2f5f3] px-4 py-3 text-sm outline-none transition-colors focus:border-[#1faf57]', errors.treatment ? 'border-red-400' : 'border-[#123b3a]/20')}
                aria-invalid={!!errors.treatment}>
                <option value="">Choose a treatment…</option>
                {treatments.map((t) => <option key={t} value={t}>{t}</option>)}
                <option value="Not sure yet">Not sure yet — please advise</option>
              </select>
              {errors.treatment && <span className="mt-1 block text-[12px] font-semibold text-red-600">{errors.treatment}</span>}
            </label>

            {durations.length > 0 && (
              <fieldset className="mt-5">
                <legend className="mb-1.5 flex items-center gap-1.5 text-[11px] font-extrabold uppercase tracking-[0.16em] text-[#123b3a]/70">
                  <Timer className="h-3.5 w-3.5" aria-hidden /> Preferred length
                </legend>
                <div className="flex flex-wrap gap-2">
                  {durations.map((d) => (
                    <Chip key={d} active={duration === d} onClick={() => setDuration(duration === d ? '' : d)}>{d}</Chip>
                  ))}
                </div>
              </fieldset>
            )}

            <fieldset className="mt-4">
              <legend className="mb-1.5 text-[11px] font-extrabold uppercase tracking-[0.16em] text-[#123b3a]/70">Pressure preference</legend>
              <div className="flex flex-wrap gap-2">
                {PRESSURE.map((p) => (
                  <Chip key={p} active={pressure === p} onClick={() => setPressure(pressure === p ? '' : p)}>{p}</Chip>
                ))}
              </div>
            </fieldset>

            <label className="mt-5 block">
              <span className="mb-1.5 block text-[11px] font-extrabold uppercase tracking-[0.16em] text-[#123b3a]/70">Preferred day &amp; time (optional)</span>
              <input value={when} onChange={(e) => setWhen(e.target.value)} placeholder="e.g. Thursday evening"
                className="w-full rounded-xl border border-[#123b3a]/20 bg-[#f2f5f3] px-4 py-3 text-sm outline-none transition-colors focus:border-[#1faf57]" />
            </label>

            <label className="mt-5 block">
              <span className="mb-1.5 block text-[11px] font-extrabold uppercase tracking-[0.16em] text-[#123b3a]/70">
                Anything we should know? (optional)
              </span>
              <textarea value={health} onChange={(e) => setHealth(e.target.value)} rows={3}
                placeholder="Injuries, allergies, pregnancy, areas to avoid…"
                className="w-full resize-none rounded-xl border border-[#123b3a]/20 bg-[#f2f5f3] px-4 py-3 text-sm outline-none transition-colors focus:border-[#1faf57]" />
              <span className="mt-1 block text-[11.5px] leading-relaxed text-[#123b3a]/55">
                Shared with your therapist so they can adapt the treatment — or tell you honestly if it isn’t suitable.
              </span>
            </label>

            {hasWa ? (
              <button type="submit"
                className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl px-5 py-4 text-[15px] font-extrabold text-white transition-transform hover:-translate-y-0.5"
                style={{ background: WA }}>
                <Send className="h-4 w-4" aria-hidden /> Draft my WhatsApp enquiry
              </button>
            ) : (
              <p className="mt-6 rounded-xl border-2 border-dashed border-[#123b3a]/30 px-4 py-3.5 text-center text-[13px] font-semibold text-[#123b3a]/60">
                The spa needs a WhatsApp number before this form can send — add one in the editor.
              </p>
            )}
            <button type="button" onClick={copy}
              className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl border border-[#123b3a]/20 px-5 py-3 text-[13px] font-bold text-[#123b3a]/75 transition-colors hover:border-[#123b3a]">
              {copied ? <Check className="h-4 w-4 text-[#1faf57]" /> : <Copy className="h-4 w-4" />}
              {copied ? 'Copied to clipboard' : 'Copy enquiry text instead'}
            </button>

            {drafted && (
              <p role="status" className="mt-4 flex items-start gap-2.5 rounded-xl bg-[#1faf57]/12 px-4 py-3 text-[12.5px] font-semibold leading-relaxed">
                <Check className="mt-0.5 h-4 w-4 shrink-0" style={{ color: WA }} />
                WhatsApp opened with your enquiry drafted. Press send there — the spa confirms availability by
                reply. Nothing is booked or held yet.
              </p>
            )}
          </form>
        </div>

        {/* ------------------------------------------------ room band */}
        {photos.length > 0 && (
          <div className="mt-14">
            <div className="mb-4 flex items-center gap-3">
              <p className="text-[11px] font-extrabold uppercase tracking-[0.2em] text-[#123b3a]/60">Inside the spa</p>
              {photos.some((p) => p.sample) && <SamplePill label="Sample photos" />}
            </div>
            <div className="grid grid-cols-2 gap-3 @md:grid-cols-4">
              {photos.slice(0, 4).map((p) => (
                <SmartImage key={p.id} src={p.src} alt={p.alt} className="aspect-[4/3] w-full rounded-xl" />
              ))}
            </div>
          </div>
        )}

        {/* ------------------------------------------------ info tiles */}
        <div className="mt-14 grid gap-4 @md:grid-cols-3">
          <div className="rounded-2xl bg-white p-6 shadow-sm">
            <p className="mb-3 flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-[0.2em] text-[#123b3a]/60">
              <Clock className="h-4 w-4" /> Opening hours
            </p>
            <ul className="space-y-2">
              {b.hours.map((h) => (
                <li key={h.id} className="flex justify-between gap-4 text-sm">
                  <span className="font-bold">{h.label}</span>
                  <span className="text-[#123b3a]/70">{h.closed ? <em>Closed</em> : formatHourRow(h)}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-2xl bg-white p-6 shadow-sm">
            <p className="mb-3 flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-[0.2em] text-[#123b3a]/60">
              <MapPin className="h-4 w-4" /> Where to find us
            </p>
            <p className="text-sm font-bold">{b.address || 'Add your address'}</p>
            <p className="text-sm text-[#123b3a]/70">{b.area || 'Your area'}</p>
            <a href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${b.address} ${b.area}`)}`}
              target="_blank" rel="noreferrer"
              className="mt-3 inline-flex items-center gap-1.5 text-[13px] font-extrabold underline decoration-[#1faf57] decoration-2 underline-offset-4">
              Get directions
            </a>
          </div>
          <div className="rounded-2xl bg-white p-6 shadow-sm">
            <p className="mb-3 flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-[0.2em] text-[#123b3a]/60">
              Popular lengths <SamplePill label="Sample" />
            </p>
            <ul className="space-y-2">
              {b.services.slice(0, 4).map((s) => (
                <li key={s.id} className="flex justify-between gap-4 text-sm">
                  <span className="min-w-0 truncate font-bold">{s.name}</span>
                  <span className="shrink-0 text-[#123b3a]/70">{s.duration ? `${s.duration} · ` : ''}{s.price}</span>
                </li>
              ))}
            </ul>
            <p className="mt-3 text-[12px] text-[#123b3a]/55">Full treatment list shared on enquiry.</p>
          </div>
        </div>
      </main>

      <footer className="flex flex-wrap items-center justify-between gap-3 border-t border-[#123b3a]/12 px-5 py-6 text-[11px] font-bold uppercase tracking-[0.2em] text-[#123b3a]/50 @md:px-10">
        <span>{name}</span>
        <span>Design: Vital · MzansiSite demo — enquiries are not confirmed bookings</span>
      </footer>
    </div>
  );
}

function Chip({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button type="button" aria-pressed={active} onClick={onClick}
      className={cn(
        'rounded-full border px-3.5 py-1.5 text-[12.5px] font-bold transition-colors',
        active ? 'border-transparent bg-[#123b3a] text-white' : 'border-[#123b3a]/25 text-[#123b3a]/75 hover:border-[#123b3a]',
      )}>
      {children}
    </button>
  );
}

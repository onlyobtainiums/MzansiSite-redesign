/**
 * Spa & Massage Therapy industry module.
 *
 * Same contract, six design directions and technical standards as the Barber
 * and Hair Salon packs — entirely different designs, sample data and imagery.
 *
 * Industry specifics: per-treatment DURATION fields (opt-in via
 * `supportsDuration`), treatment descriptions, pressure/health enquiry fields,
 * and strict imagery rules. No booking system, no music, no audio.
 */
import type { IndustryModule } from '../types';
import { freshSampleContent, SAMPLE_PHOTOS } from './data/spaPack';
import { TEMPLATES } from './templates/registry';

export const spaIndustry: IndustryModule = {
  id: 'spa',
  label: 'Spa / Massage',
  packKicker: 'Spa & Massage Template Pack · 6 designs',
  chooserHeadline: 'Six ways to put your spa online.',
  chooserIntro:
    'Six genuinely different designs, each a real working website with treatment durations, prices and enquiry flows. Add your details and photos in a free preview, and only pay when you’re ready to publish. Switching designs keeps everything you’ve typed.',
  imageryNote:
    'Imagery rule (Islamic-values compliant): treatment rooms, towels, oils, candles and products only — no people, faces, bodies, hands or immodest imagery. No music or audio anywhere in the pack.',
  draftKey: 'mzansisite.draft.spa.v1',
  supportsDuration: true,
  servicesLabel: 'Treatments',
  sampleBusiness: freshSampleContent,
  samplePhotos: SAMPLE_PHOTOS,
  templates: TEMPLATES,
};

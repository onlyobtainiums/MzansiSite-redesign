# Spa / Massage Therapy Industry Pack — MzansiSite Studio (v1)

A third, parallel industry pack: six genuinely new designs under the same six family
directions, the same technical standards, and the same integration approach as the Barber
and Hair Salon packs — **with zero modifications to either existing pack**.

## What is genuinely Spa / Massage (not a rename)

| Family  | Direction       | Spa identity & composition |
|---------|-----------------|-----------------------------|
| Velvet  | Hero-first      | Stillness as the opening statement — near-black teal + warm stone, one calm frame, **duration beside every price**, "the room is ready" visit block |
| Forge   | Services-first  | A clinical **treatment matrix**: filter by *duration band* (≤45 / 46–75 / 76+ min) and category, three-column Treatment · Duration · From layout |
| Savanna | Trust-first     | **How a visit works** (arrive → consult → treatment → rest), care & comfort practices, explicit **health-honesty note**, no outcome claims |
| Praxis  | Gallery-first   | A bright, airy **room tour** — wide establishing frame, calm masonry of spaces, duration-tagged treatment captions |
| Market  | About-first     | **Philosophy in slow vertical rhythm** — centred ivory column, wide margins, pull-quote, copper rules |
| Vital   | Enquiry-first   | **Treatment enquiry**: treatment select → duration chips (derived from that treatment's lengths) → pressure preference → health-notes field, drafted into one WhatsApp message |

- **Sample business**: "Still Point Wellness", Morningside, Durban — 16 treatments across 5 spa
  categories (Massage / Body / Face / Hands & Feet / Packages), each with **duration + price**,
  Monday closed, shorter Sunday hours. All clearly labelled sample content.

## Industry-specific fields

- **Treatment duration** — a new optional `ServiceItem.duration` field, surfaced only for
  industries declaring `supportsDuration: true`. Free text ("60 min", "1 hr 30"), with Forge's
  filter parsing the number. Barber and Hair Salon editors are unchanged because they don't opt in.
- **Treatment descriptions**, price, category, opening days/times/closed days, full contact set.
- **Enquiry fields**: preferred length, pressure preference, and an optional health-notes field
  whose helper text explains it is shared with the therapist.
- Editor tab is relabelled "Treatments" via `servicesLabel`.

## Honesty & safety rules observed

- **No booking system.** Every enquiry path states it is *not* a booking; the spa confirms by reply.
  Nothing is held, reserved or marked confirmed.
- **No medical claims.** No template says a treatment diagnoses, treats, cures or relieves any
  condition. Savanna explicitly advises checking with a doctor where relevant and states
  "we give treatment guidance, not medical advice".
- **No invented credentials, reviews, ratings or awards** — `credentials` ships empty with an
  honest empty state.
- **No music, no audio, no autoplay media** anywhere in the pack.

## Imagery rules (Islamic-values compliant)

Treatment rooms, massage tables, towels, oils, candles, stones and product still lifes **only** —
no people, faces, bodies, hands or immodest imagery. All eight sample photos are curated
people-free stock (CDN-loaded); people-containing search results were rejected during selection.
The rule is declared in `industry.imageryNote` and shown in the chooser's honesty panel.

> Note: the session's AI image-generation quota was exhausted by the first two packs, so this
> pack uses curated stock photography only. If locally bundled art is preferred later, generate
> replacements into `src/industries/spa/assets/` and swap the `src` values in `data/spaPack.ts`.

## Structure (mirrors the previous packs)

```
src/industries/spa/
  index.ts                     IndustryModule (labels, imagery note, supportsDuration, draft key)
  data/spaPack.ts              Labelled SAMPLE content (treatments, durations, prices, hours, photos)
  templates/registry.ts        Six families: id, name, strategy, blurb, palette, component
  templates/<family>/<Family>Template.tsx   Velvet · Forge · Savanna · Praxis · Market · Vital
  README.md                    This file
```

Loads through the same shared machinery: `src/industries/types.ts` → `src/industries/index.ts`
(`INDUSTRIES` list) → `App.tsx` → `StudioProvider` (per-industry draft `mzansisite.draft.spa.v1`)
→ chooser/studio render `industry.templates`.

## Requirements parity

Free preview = 6 **own** photos (samples don't count) enforced in the state action via
`deriveEntitlement`; paid expansion only via a server-verified platform session; photo
add/replace/remove/reorder; all business fields editable incl. structured hours; tab-local text
draft with honest persistence copy; sample labelling; responsive container queries; reduced-motion
respected; auto-rotating selector with manual controls. The paid photo limit remains
**undefined by design** — awaiting the platform plan catalogue (root README §6–7).

## Verification checklist (pack-specific)

- [ ] Spa is the default pack; Barber and Hair Salon still load fully via the switcher.
- [ ] Each pack keeps its own draft (edit spa text, switch away and back → restored).
- [ ] All six spa designs render in the rotating chooser and in mobile/desktop frames.
- [ ] Duration shows in Velvet, Forge, Savanna, Praxis, Market and Vital; editing it updates live.
- [ ] Forge duration-band filters (≤45 / 46–75 / 76+) return the expected treatments.
- [ ] Vital: duration chips change with the selected treatment; form validates; draft message
      includes treatment, length, pressure and health notes, and says "not a booking".
- [ ] Monday shows "Closed" across all six designs.
- [ ] No image depicts people; no audio element exists anywhere (`grep -i "audio\|<music"` → none).
- [ ] `npm run build` succeeds with all three packs bundled.
